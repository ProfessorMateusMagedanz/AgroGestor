CREATE TABLE public.employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text,
  phone text NOT NULL DEFAULT '',
  job_title text NOT NULL DEFAULT '',
  sector text NOT NULL DEFAULT '',
  hired_at date,
  salary numeric NOT NULL DEFAULT 0 CHECK (salary >= 0),
  user_id uuid,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX employees_property_email ON public.employees(property_id, lower(email)) WHERE email IS NOT NULL AND email <> '';
CREATE TABLE public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  due_date date,
  priority text NOT NULL DEFAULT 'Média' CHECK (priority IN ('Baixa','Média','Alta')),
  status text NOT NULL DEFAULT 'Pendente' CHECK (status IN ('Pendente','Em andamento','Feita')),
  completed_at timestamptz,
  seen_by_employee boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  month text NOT NULL CHECK (month ~ '^\d{4}-\d{2}$'),
  kind text NOT NULL DEFAULT 'Salário' CHECK (kind IN ('Salário','Adiantamento','Desconto','Bônus')),
  amount numeric NOT NULL CHECK (amount >= 0),
  status text NOT NULL DEFAULT 'Pendente' CHECK (status IN ('Pago','Pendente')),
  paid_at date,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.employees, public.tasks, public.payments TO authenticated;
GRANT ALL ON public.employees, public.tasks, public.payments TO service_role;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.my_employee_ids() RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT id FROM public.employees WHERE user_id = auth.uid() $$;

CREATE POLICY employees_admin ON public.employees FOR ALL TO authenticated
  USING (public.can_access_property(property_id, true)) WITH CHECK (public.can_access_property(property_id, true));
CREATE POLICY employees_self ON public.employees FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE POLICY tasks_admin ON public.tasks FOR ALL TO authenticated
  USING (public.can_access_property(property_id, true)) WITH CHECK (public.can_access_property(property_id, true));
CREATE POLICY tasks_self_read ON public.tasks FOR SELECT TO authenticated USING (employee_id IN (SELECT public.my_employee_ids()));

CREATE POLICY payments_admin ON public.payments FOR ALL TO authenticated
  USING (public.can_access_property(property_id, true)) WITH CHECK (public.can_access_property(property_id, true));
CREATE POLICY payments_self_read ON public.payments FOR SELECT TO authenticated USING (employee_id IN (SELECT public.my_employee_ids()));

-- Employee changes only the status of their own task
CREATE OR REPLACE FUNCTION public.set_my_task_status(t uuid, s text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF s NOT IN ('Pendente','Em andamento','Feita') THEN RAISE EXCEPTION 'Status inválido'; END IF;
  UPDATE public.tasks SET status = s, seen_by_employee = true, updated_at = now(),
    completed_at = CASE WHEN s = 'Feita' THEN now() ELSE NULL END
  WHERE id = t AND employee_id IN (SELECT id FROM public.employees WHERE user_id = auth.uid());
  IF NOT FOUND THEN RAISE EXCEPTION 'Tarefa não encontrada'; END IF;
END $$;

-- Link signed-in user to employee records registered with their e-mail
CREATE OR REPLACE FUNCTION public.claim_employee() RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n integer; em text;
BEGIN
  SELECT lower(email) INTO em FROM auth.users WHERE id = auth.uid();
  IF em IS NULL THEN RETURN 0; END IF;
  UPDATE public.employees SET user_id = auth.uid() WHERE user_id IS NULL AND lower(email) = em;
  GET DIAGNOSTICS n = ROW_COUNT; RETURN n;
END $$;

REVOKE EXECUTE ON FUNCTION public.set_my_task_status(uuid, text), public.claim_employee(), public.my_employee_ids() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_my_task_status(uuid, text), public.claim_employee(), public.my_employee_ids() TO authenticated;

ALTER PUBLICATION supabase_realtime ADD TABLE public.tasks;