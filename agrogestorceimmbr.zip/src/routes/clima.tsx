import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AlertTriangle, CheckCircle2, Cloud, CloudLightning, CloudRain, CloudSun, Crosshair, Droplets, MapPin, Search, Sparkles, Sun, Wind, XCircle } from "lucide-react";
import { PageHeader } from "@/components/CrudPage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { askAssistant } from "@/lib/ai.functions";
import { readCollection } from "@/lib/store";
import { alertas, buscarCidade, carregarClima, descricao, fmtD, getLocal, recomendacoes, setLocal, type Clima, type Dia, type Local } from "@/lib/weather";

export const Route = createFileRoute("/clima")({
  head: () => ({ meta: [
    { title: "Clima da Fazenda — AgroGestor" },
    { name: "description", content: "Previsão do tempo real para a cidade ou localização da sua fazenda, com alertas e dicas simples de manejo." },
    { property: "og:title", content: "Clima da Fazenda — AgroGestor" },
    { property: "og:description", content: "Saiba em segundos se hoje dá para pulverizar, plantar ou colher." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: ClimaPage,
});

function Icone({ codigo, className }: { codigo: number; className?: string }) {
  if (codigo === 0) return <Sun className={className} />;
  if (codigo <= 3) return <CloudSun className={className} />;
  if (codigo <= 48) return <Cloud className={className} />;
  if (codigo >= 95) return <CloudLightning className={className} />;
  return <CloudRain className={className} />;
}

function Sinal({ ok, titulo, motivo }: { ok: boolean; titulo: string; motivo: string }) {
  return (
    <div className={`flex items-start gap-3 rounded-xl border p-4 ${ok ? "border-primary/40 bg-primary/5" : "border-destructive/40 bg-destructive/5"}`}>
      {ok ? <CheckCircle2 className="size-8 shrink-0 text-primary" /> : <XCircle className="size-8 shrink-0 text-destructive" />}
      <div>
        <div className="font-display text-base">{titulo}</div>
        <div className={`text-sm font-semibold ${ok ? "text-primary" : "text-destructive"}`}>{ok ? "Pode sim" : "Melhor não"}</div>
        <div className="text-xs text-muted-foreground">{motivo}</div>
      </div>
    </div>
  );
}

function sinais(h: Dia) {
  return [
    { titulo: "Pulverizar hoje?", ok: h.prob < 30 && h.vento < 20 && h.max < 32,
      motivo: h.vento >= 20 ? `Vento forte (${h.vento.toFixed(0)} km/h)` : h.prob >= 30 ? `${h.prob}% de chance de chuva` : h.max >= 32 ? `Muito calor (${h.max.toFixed(0)}°C)` : "Tempo firme e vento fraco" },
    { titulo: "Colher / transportar?", ok: h.prob < 40,
      motivo: h.prob < 40 ? "Pouca chance de chuva" : `${h.prob}% de chance de chuva` },
    { titulo: "Plantar / adubar?", ok: h.chuva >= 5 || h.prob >= 50,
      motivo: h.chuva >= 5 || h.prob >= 50 ? "Umidade boa no solo" : "Solo pode estar seco" },
  ];
}

function ClimaPage() {
  const ask = useServerFn(askAssistant);
  const [clima, setClima] = useState<Clima | null>(null);
  const [err, setErr] = useState("");
  const [q, setQ] = useState("");
  const [opts, setOpts] = useState<Local[]>([]);
  const [ia, setIa] = useState("");
  const [iaLoad, setIaLoad] = useState(false);
  const [trocar, setTrocar] = useState(false);

  const load = (l: Local) => { setErr(""); setIa(""); carregarClima(l).then(setClima).catch(() => setErr("Não consegui carregar a previsão. Verifique a internet.")); };
  useEffect(() => { load(getLocal()); }, []);

  useEffect(() => {
    if (q.trim().length < 3) { setOpts([]); return; }
    const t = setTimeout(() => buscarCidade(q).then(setOpts).catch(() => setOpts([])), 350);
    return () => clearTimeout(t);
  }, [q]);

  const escolher = (l: Local) => { setLocal(l); setOpts([]); setQ(""); setTrocar(false); load(l); };

  function gps() {
    if (!navigator.geolocation) return setErr("Seu aparelho não permite localização.");
    navigator.geolocation.getCurrentPosition(
      (p) => escolher({ nome: "Minha fazenda (GPS)", lat: p.coords.latitude, lon: p.coords.longitude }),
      () => setErr("Não foi possível pegar a localização. Permita o acesso ou busque a cidade."),
    );
  }

  async function planoIA() {
    if (!clima) return;
    setIaLoad(true);
    const ctx = JSON.stringify({ clima: { local: clima.local.nome, atual: clima.atual, dias: clima.dias }, talhoes: readCollection("culturas").map(({ id, ...r }) => r), eventos: readCollection("eventos").slice(0, 20) });
    try {
      const { reply } = await ask({ data: { context: ctx.slice(0, 19000), messages: [{ role: "user", content: "Com base na previsão dos próximos 7 dias e nos meus talhões, diga em linguagem bem simples o que fazer em cada dia (plantar, pulverizar, adubar, colher). No máximo 1 linha por dia, sem termos técnicos difíceis." }] } });
      setIa(reply);
    } catch { setIa("Erro ao conectar com a IA."); }
    setIaLoad(false);
  }

  const al = clima ? alertas(clima) : [];
  const rec = clima ? recomendacoes(clima) : [];
  const hoje = clima?.dias[0];

  return (
    <div className="space-y-5">
      <PageHeader title="Clima da Fazenda" subtitle="Previsão real para os próximos 7 dias" />

      <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <MapPin className="size-5 text-primary" />
            <div>
              <div className="text-xs text-muted-foreground">Local da previsão</div>
              <div className="font-display text-lg">{clima?.local.nome ?? "Carregando…"}</div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={gps}><Crosshair /> Usar minha localização</Button>
            <Button variant="secondary" size="sm" onClick={() => setTrocar((v) => !v)}><Search /> Trocar cidade</Button>
          </div>
        </div>
        {trocar && (
          <div className="mt-3">
            <Input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Digite a cidade da fazenda (ex: Rio Verde, Lucas do Rio Verde)" />
            {opts.length > 0 && (
              <div className="mt-2 divide-y divide-border rounded-lg border border-border">
                {opts.map((o) => (
                  <button key={o.nome + o.lat} onClick={() => escolher(o)} className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-muted">
                    <MapPin className="size-4 text-muted-foreground" /> {o.nome}
                  </button>
                ))}
              </div>
            )}
            {q.trim().length >= 3 && opts.length === 0 && <p className="mt-2 text-xs text-muted-foreground">Nenhuma cidade encontrada ainda…</p>}
          </div>
        )}
      </div>

      {err && <p className="text-sm text-destructive">{err}</p>}
      {!clima && !err && <p className="text-sm text-muted-foreground">Carregando previsão…</p>}

      {clima && hoje && (
        <>
          <div className="grid gap-4 lg:grid-cols-[1fr_1.4fr]">
            <div className="rounded-xl bg-gradient-to-br from-primary to-primary/70 p-5 text-primary-foreground shadow-soft">
              <div className="text-sm opacity-90">Agora</div>
              <div className="flex items-center gap-4">
                <Icone codigo={clima.atual.codigo} className="size-16" />
                <div>
                  <div className="font-display text-5xl">{clima.atual.temp.toFixed(0)}°C</div>
                  <div className="text-sm opacity-90">{descricao(clima.atual.codigo)}</div>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center text-sm">
                <div className="rounded-lg bg-background/15 p-2"><CloudRain className="mx-auto size-4" />{hoje.prob}% chuva</div>
                <div className="rounded-lg bg-background/15 p-2"><Droplets className="mx-auto size-4" />{clima.atual.umidade}% umid.</div>
                <div className="rounded-lg bg-background/15 p-2"><Wind className="mx-auto size-4" />{clima.atual.vento.toFixed(0)} km/h</div>
              </div>
            </div>
            <div>
              <h2 className="mb-2 font-display text-lg">O que dá para fazer hoje</h2>
              <div className="grid gap-2 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
                {sinais(hoje).map((s) => <Sinal key={s.titulo} {...s} />)}
              </div>
            </div>
          </div>

          {al.length > 0 && (
            <div className="space-y-2">
              {al.map((a) => (
                <div key={a.titulo} className={`flex items-start gap-3 rounded-xl p-3 text-sm ${a.nivel === "alto" ? "bg-destructive/10" : "bg-accent/20"}`}>
                  <AlertTriangle className={`size-5 shrink-0 ${a.nivel === "alto" ? "text-destructive" : "text-foreground"}`} />
                  <div><b>{a.titulo}:</b> <span className="text-muted-foreground">{a.texto}</span></div>
                </div>
              ))}
            </div>
          )}

          <div>
            <h2 className="mb-2 font-display text-lg">Próximos 7 dias</h2>
            <div className="flex gap-2 overflow-x-auto pb-2">
              {clima.dias.map((d, i) => (
                <div key={d.data} className={`min-w-[110px] flex-1 rounded-xl border bg-card p-3 text-center shadow-soft ${i === 0 ? "border-primary" : "border-border"}`}>
                  <div className="text-xs font-semibold uppercase text-muted-foreground">{i === 0 ? "Hoje" : fmtD(d.data)}</div>
                  <Icone codigo={d.codigo} className="mx-auto my-2 size-8 text-primary" />
                  <div className="font-display text-lg">{d.max.toFixed(0)}° <span className="text-sm text-muted-foreground">{d.min.toFixed(0)}°</span></div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full bg-primary" style={{ width: `${d.prob}%` }} /></div>
                  <div className="mt-1 text-xs text-muted-foreground">{d.prob}% · {d.chuva.toFixed(0)} mm</div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
            <h2 className="mb-2 font-display text-lg">Dicas da semana</h2>
            <ul className="space-y-2 text-sm">{rec.map((r) => <li key={r} className="flex gap-2"><CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" />{r}</li>)}</ul>
          </div>

          <div className="rounded-xl border-2 border-primary/40 bg-card p-4 shadow-soft">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="flex items-center gap-2 font-display text-lg"><Sparkles className="size-5 text-primary" /> Plano simples da IA</h2>
                <p className="text-xs text-muted-foreground">A IA olha o clima e seus talhões e diz o que fazer em cada dia.</p>
              </div>
              <Button onClick={planoIA} disabled={iaLoad}>{iaLoad ? "Gerando…" : "Gerar plano"}</Button>
            </div>
            {ia && <p className="mt-3 whitespace-pre-wrap text-sm">{ia}</p>}
          </div>
        </>
      )}
    </div>
  );
}
