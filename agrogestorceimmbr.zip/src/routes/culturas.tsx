import { createFileRoute } from "@tanstack/react-router";
import { CrudPage, StatCard } from "@/components/CrudPage";
import { brl, type Item } from "@/lib/store";

const fmt = (d: unknown) => (d ? String(d).split("-").reverse().join("/") : "—");
const n = (v: unknown) => Number(v) || 0;
export const custoHa = (i: Item) => (n(i.area) ? n(i.custo) / n(i.area) : 0);

export const Route = createFileRoute("/culturas")({
  head: () => ({ meta: [
    { title: "Talhões e Culturas — AgroGestor" }, { name: "description", content: "Talhões, área em hectares, cultura, insumos, custo de produção e produtividade por área." },
    { property: "og:title", content: "Talhões e Culturas — AgroGestor" }, { property: "og:description", content: "Gestão de talhões, custos e produtividade." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: () => (
    <CrudPage collection="culturas" title="Talhões e Culturas" subtitle="Identificação, área, insumos, custo e produtividade por hectare"
      fields={[
        { name: "talhao", label: "Identificação do talhão (ex: T-01 Sede)" },
        { name: "nome", label: "Cultura plantada (ex: Soja)" },
        { name: "area", label: "Tamanho (ha)", type: "number" },
        { name: "plantio", label: "Data de plantio", type: "date" },
        { name: "colheita", label: "Previsão de colheita", type: "date" },
        { name: "insumos", label: "Insumos utilizados (ex: Semente TMG, MAP 300kg/ha, glifosato)" },
        { name: "custo", label: "Custo de produção total (R$)", type: "number" },
        { name: "produtividade", label: "Produtividade (sc/ha)", type: "number" },
        { name: "preco", label: "Preço da saca (R$)", type: "number" },
        { name: "status", label: "Status", type: "select", options: ["Planejada", "Plantada", "Em desenvolvimento", "Colhida"] },
      ]}
      summary={(items) => {
        const area = items.reduce((s, i) => s + n(i.area), 0);
        const custo = items.reduce((s, i) => s + n(i.custo), 0);
        const prod = area ? items.reduce((s, i) => s + n(i.produtividade) * n(i.area), 0) / area : 0;
        const receita = items.reduce((s, i) => s + n(i.produtividade) * n(i.area) * n(i.preco), 0);
        return (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <StatCard label="Área total" value={`${area.toLocaleString("pt-BR")} ha`} />
            <StatCard label="Custo médio / ha" value={brl(area ? custo / area : 0)} tone="bad" />
            <StatCard label="Produtividade média" value={`${prod.toFixed(1)} sc/ha`} tone="good" />
            <StatCard label="Margem estimada" value={brl(receita - custo)} tone={receita - custo >= 0 ? "good" : "bad"} />
          </div>
        );
      }}
      renderTitle={(i) => `${i.talhao || "Sem talhão"} · ${i.nome}`}
      renderMeta={(i) => (
        <div className="space-y-0.5">
          <div>Plantio {fmt(i.plantio)} · Colheita {fmt(i.colheita)} · {i.status}</div>
          {i.insumos ? <div>Insumos: {i.insumos}</div> : null}
          <div>Custo {brl(n(i.custo))} · <b>{brl(custoHa(i))}/ha</b> · {n(i.produtividade)} sc/ha{n(i.preco) ? ` · Margem ${brl(n(i.produtividade) * n(i.area) * n(i.preco) - n(i.custo))}` : ""}</div>
        </div>
      )}
      renderRight={(i) => <span className="font-display text-lg">{i.area} ha</span>}
    />
  ),
});
