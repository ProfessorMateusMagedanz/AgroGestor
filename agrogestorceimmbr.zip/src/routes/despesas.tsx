import { createFileRoute } from "@tanstack/react-router";
import { CrudPage, StatCard } from "@/components/CrudPage";
import { brl, sum } from "@/lib/store";

const fmt = (d: unknown) => String(d).split("-").reverse().join("/");

export const Route = createFileRoute("/despesas")({
  head: () => ({ meta: [
    { title: "Despesas — AgroGestor" }, { name: "description", content: "Registre e acompanhe as despesas da fazenda." },
    { property: "og:title", content: "Despesas — AgroGestor" }, { property: "og:description", content: "Controle de despesas rurais." },
  ] }),
  component: () => (
    <CrudPage collection="despesas" title="Despesas" subtitle="Insumos, mão de obra, combustível e mais"
      fields={[
        { name: "descricao", label: "Descrição" },
        { name: "categoria", label: "Categoria", type: "select", options: ["Insumos", "Sementes", "Fertilizantes", "Defensivos", "Combustível", "Mão de obra", "Manutenção", "Impostos", "Pecuária", "Outros"] },
        { name: "valor", label: "Valor (R$)", type: "number" },
        { name: "data", label: "Data", type: "date" },
      ]}
      summary={(i) => <StatCard label="Total de despesas" value={brl(sum(i))} tone="bad" />}
      renderTitle={(i) => i.descricao}
      renderMeta={(i) => `${i.categoria} · ${fmt(i.data)}`}
      renderRight={(i) => <span className="font-medium text-destructive">-{brl(Number(i.valor))}</span>}
    />
  ),
});
