import { createFileRoute } from "@tanstack/react-router";
import { CrudPage, StatCard } from "@/components/CrudPage";
import { brl } from "@/lib/store";

export const Route = createFileRoute("/estoque")({
  head: () => ({ meta: [
    { title: "Estoque — AgroGestor" }, { name: "description", content: "Controle de insumos, sementes e produtos armazenados." },
    { property: "og:title", content: "Estoque — AgroGestor" }, { property: "og:description", content: "Estoque de insumos da fazenda." },
  ] }),
  component: () => (
    <CrudPage collection="estoque" title="Estoque" subtitle="Insumos, sementes e produção armazenada"
      fields={[
        { name: "item", label: "Item" },
        { name: "quantidade", label: "Quantidade", type: "number" },
        { name: "unidade", label: "Unidade", type: "select", options: ["kg", "sc", "L", "t", "un"] },
        { name: "minimo", label: "Estoque mínimo", type: "number" },
        { name: "custo", label: "Custo unitário (R$)", type: "number" },
      ]}
      summary={(items) => (
        <div className="grid grid-cols-2 gap-3">
          <StatCard label="Valor em estoque" value={brl(items.reduce((s, i) => s + Number(i.quantidade) * Number(i.custo), 0))} />
          <StatCard label="Abaixo do mínimo" value={items.filter((i) => Number(i.quantidade) < Number(i.minimo)).length} tone="bad" />
        </div>
      )}
      renderTitle={(i) => i.item}
      renderMeta={(i) => `Mínimo ${i.minimo} ${i.unidade} · ${brl(Number(i.custo))}/${i.unidade}`}
      renderRight={(i) => (
        <span className={`font-display text-lg ${Number(i.quantidade) < Number(i.minimo) ? "text-destructive" : ""}`}>
          {i.quantidade} {i.unidade}
        </span>
      )}
    />
  ),
});
