import { createFileRoute } from "@tanstack/react-router";
import { CrudPage } from "@/components/CrudPage";

const fmt = (d: unknown) => (d ? String(d).split("-").reverse().join("/") : "—");

export const Route = createFileRoute("/maquinas")({
  head: () => ({ meta: [
    { title: "Máquinas — AgroGestor" }, { name: "description", content: "Frota de máquinas, horas de uso e manutenções." },
    { property: "og:title", content: "Máquinas — AgroGestor" }, { property: "og:description", content: "Gestão de máquinas agrícolas." },
  ] }),
  component: () => (
    <CrudPage collection="maquinas" title="Máquinas" subtitle="Tratores, colheitadeiras e implementos"
      fields={[
        { name: "nome", label: "Máquina (ex: Trator JD 6110)" },
        { name: "tipo", label: "Tipo", type: "select", options: ["Trator", "Colheitadeira", "Pulverizador", "Plantadeira", "Caminhão", "Implemento", "Outro"] },
        { name: "horas", label: "Horímetro (h)", type: "number" },
        { name: "manutencao", label: "Próxima manutenção", type: "date" },
        { name: "status", label: "Status", type: "select", options: ["Operando", "Em manutenção", "Parada"] },
      ]}
      renderTitle={(i) => i.nome}
      renderMeta={(i) => `${i.tipo} · ${i.horas} h · Manutenção ${fmt(i.manutencao)}`}
      renderRight={(i) => (
        <span className={`rounded-full px-2 py-0.5 text-xs ${i.status === "Operando" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`}>{i.status}</span>
      )}
    />
  ),
});
