import { createFileRoute } from "@tanstack/react-router";
import { CrudPage, StatCard } from "@/components/CrudPage";
import { brl, sum } from "@/lib/store";

const fmt = (d: unknown) => String(d).split("-").reverse().join("/");

export const Route = createFileRoute("/receitas")({
  head: () => ({ meta: [
    { title: "Receitas — AgroGestor" }, { name: "description", content: "Registre as vendas e receitas da fazenda." },
    { property: "og:title", content: "Receitas — AgroGestor" }, { property: "og:description", content: "Controle de receitas rurais." },
  ] }),
  component: () => (
    <CrudPage collection="receitas" title="Receitas" subtitle="Vendas de safra, gado e serviços"
      fields={[
        { name: "descricao", label: "Descrição" },
        { name: "categoria", label: "Categoria", type: "select", options: ["Venda de grãos", "Venda de gado", "Leite", "Hortifruti", "Arrendamento", "Serviços", "Outros"] },
        { name: "valor", label: "Valor (R$)", type: "number" },
        { name: "data", label: "Data", type: "date" },
      ]}
      summary={(i) => <StatCard label="Total de receitas" value={brl(sum(i))} tone="good" />}
      renderTitle={(i) => i.descricao}
      renderMeta={(i) => `${i.categoria} · ${fmt(i.data)}`}
      renderRight={(i) => <span className="font-medium text-success">+{brl(Number(i.valor))}</span>}
    />
  ),
});
