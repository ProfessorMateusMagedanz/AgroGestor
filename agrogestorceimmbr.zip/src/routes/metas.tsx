import { createFileRoute } from "@tanstack/react-router";
import { CrudPage } from "@/components/CrudPage";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/metas")({
  head: () => ({ meta: [
    { title: "Metas — AgroGestor" }, { name: "description", content: "Defina e acompanhe metas de produção e faturamento." },
    { property: "og:title", content: "Metas — AgroGestor" }, { property: "og:description", content: "Metas da fazenda." },
  ] }),
  component: () => (
    <CrudPage collection="metas" title="Metas" subtitle="Produtividade, faturamento e redução de custos"
      fields={[
        { name: "titulo", label: "Meta (ex: Faturar R$ 500 mil)" },
        { name: "alvo", label: "Valor alvo", type: "number" },
        { name: "atual", label: "Valor atual", type: "number" },
        { name: "prazo", label: "Prazo", type: "date" },
      ]}
      renderTitle={(i) => i.titulo}
      renderMeta={(i) => {
        const p = Math.min(100, Math.round((Number(i.atual) / (Number(i.alvo) || 1)) * 100));
        return (
          <div className="mt-2 space-y-1">
            <Progress value={p} />
            <span>{i.atual} de {i.alvo} · {p}% · até {String(i.prazo).split("-").reverse().join("/")}</span>
          </div>
        );
      }}
    />
  ),
});
