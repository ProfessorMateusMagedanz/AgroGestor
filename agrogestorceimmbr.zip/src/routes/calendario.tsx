import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PageHeader } from "@/components/CrudPage";
import { useCollection } from "@/lib/store";

export const Route = createFileRoute("/calendario")({
  head: () => ({ meta: [
    { title: "Calendário — AgroGestor" }, { name: "description", content: "Escreva lembretes nas datas: plantio, colheita, aplicações e pagamentos." },
    { property: "og:title", content: "Calendário — AgroGestor" }, { property: "og:description", content: "Calendário agrícola com lembretes." },
  ] }),
  component: Calendario,
});

const MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
const TIPOS = ["Lembrete", "Plantio", "Colheita", "Aplicação", "Manutenção", "Pagamento", "Recebimento"];
const iso = (y: number, m: number, d: number) => `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

function Calendario() {
  const { items, add, remove } = useCollection("eventos");
  const now = new Date();
  const [ym, setYm] = useState({ y: now.getFullYear(), m: now.getMonth() });
  const [dia, setDia] = useState<string | null>(null);
  const [texto, setTexto] = useState("");
  const [tipo, setTipo] = useState(TIPOS[0]!);
  const hoje = iso(now.getFullYear(), now.getMonth(), now.getDate());

  const first = new Date(ym.y, ym.m, 1).getDay();
  const dias = new Date(ym.y, ym.m + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(first).fill(null), ...Array.from({ length: dias }, (_, i) => i + 1)];
  const move = (n: number) => setYm(({ y, m }) => { const d = new Date(y, m + n, 1); return { y: d.getFullYear(), m: d.getMonth() }; });
  const doDia = dia ? items.filter((e) => e.data === dia) : [];

  function salvar(e: React.FormEvent) {
    e.preventDefault();
    if (!texto.trim() || !dia) return;
    add({ titulo: texto.trim(), tipo, data: dia });
    setTexto("");
  }

  return (
    <div>
      <PageHeader title="Calendário" subtitle="Toque em uma data para escrever um lembrete" />
      <div className="rounded-xl border border-border bg-card p-3 shadow-soft md:p-5">
        <div className="mb-3 flex items-center justify-between">
          <Button variant="ghost" size="icon" onClick={() => move(-1)} aria-label="Mês anterior"><ChevronLeft /></Button>
          <h2 className="font-display text-xl">{MESES[ym.m]} {ym.y}</h2>
          <Button variant="ghost" size="icon" onClick={() => move(1)} aria-label="Próximo mês"><ChevronRight /></Button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-[11px] uppercase text-muted-foreground">
          {["D", "S", "T", "Q", "Q", "S", "S"].map((d, i) => <div key={i} className="py-1">{d}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((d, i) => {
            if (!d) return <div key={i} />;
            const key = iso(ym.y, ym.m, d);
            const evs = items.filter((e) => e.data === key);
            return (
              <button key={i} onClick={() => setDia(key)}
                className={`flex min-h-16 flex-col items-stretch rounded-lg border p-1 text-left transition-colors hover:bg-secondary md:min-h-24 ${key === hoje ? "border-primary bg-primary/5" : "border-border"}`}>
                <span className={`text-xs font-medium ${key === hoje ? "text-primary" : ""}`}>{d}</span>
                {evs.slice(0, 2).map((e) => (
                  <span key={e.id} className="mt-0.5 truncate rounded bg-accent/40 px-1 text-[10px] leading-4 text-accent-foreground">{e.titulo}</span>
                ))}
                {evs.length > 2 && <span className="text-[10px] text-muted-foreground">+{evs.length - 2}</span>}
              </button>
            );
          })}
        </div>
      </div>

      <Dialog open={!!dia} onOpenChange={(o) => !o && setDia(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Lembretes de {dia?.split("-").reverse().join("/")}</DialogTitle></DialogHeader>
          <ul className="space-y-2">
            {doDia.length === 0 && <li className="text-sm text-muted-foreground">Nenhum lembrete neste dia.</li>}
            {doDia.map((e) => (
              <li key={e.id} className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2 text-sm">
                <span className="flex-1"><b className="font-medium">{e.titulo}</b> <span className="text-muted-foreground">· {e.tipo}</span></span>
                <Button variant="ghost" size="icon" onClick={() => remove(e.id)} aria-label="Excluir"><Trash2 /></Button>
              </li>
            ))}
          </ul>
          <form onSubmit={salvar} className="space-y-2">
            <Input value={texto} onChange={(e) => setTexto(e.target.value)} placeholder="Escreva o lembrete…" autoFocus />
            <div className="flex gap-2">
              <select value={tipo} onChange={(e) => setTipo(e.target.value)} className="h-9 flex-1 rounded-md border border-input bg-background px-3 text-sm">
                {TIPOS.map((t) => <option key={t}>{t}</option>)}
              </select>
              <Button type="submit">Salvar</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
