import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Send, Bot, Camera, Bug, CheckCircle2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PageHeader } from "@/components/CrudPage";
import { askAssistant, readReceipt, diagnosePest, type Diag } from "@/lib/ai.functions";
import { readCollection, useCollection, brl, type Collection } from "@/lib/store";
import { fileToDataUrl } from "@/lib/image";
import { cachedClima } from "@/lib/weather";

export const Route = createFileRoute("/assistente")({
  head: () => ({ meta: [
    { title: "Assistente IA — AgroGestor" }, { name: "description", content: "Converse, lance despesas por foto e identifique pragas com IA." },
    { property: "og:title", content: "Assistente IA — AgroGestor" }, { property: "og:description", content: "Assistente inteligente para o produtor rural." },
  ] }),
  component: Assistente,
});

function Assistente() {
  return (
    <div>
      <PageHeader title="Assistente IA" subtitle="Converse, lance por foto e identifique pragas" />
      <Tabs defaultValue="foto">
        <TabsList className="mb-4 grid w-full grid-cols-3">
          <TabsTrigger value="foto"><Camera className="size-4" /> Lançar foto</TabsTrigger>
          <TabsTrigger value="praga"><Bug className="size-4" /> Praga</TabsTrigger>
          <TabsTrigger value="chat"><Bot className="size-4" /> Conversa</TabsTrigger>
        </TabsList>
        <TabsContent value="foto"><FotoLancamento /></TabsContent>
        <TabsContent value="praga"><FotoPraga /></TabsContent>
        <TabsContent value="chat"><Chat /></TabsContent>
      </Tabs>
    </div>
  );
}

function PhotoPicker({ label, photo, onPhoto }: { label: string; photo: string | null; onPhoto: (d: string | null) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
      <input ref={ref} type="file" accept="image/*" capture="environment" className="hidden"
        onChange={async (e) => { const f = e.target.files?.[0]; if (f) onPhoto(await fileToDataUrl(f)); e.target.value = ""; }} />
      {photo ? (
        <div className="relative">
          <img src={photo} alt="Foto enviada" className="max-h-80 w-full rounded-lg object-contain bg-muted" />
          <Button variant="secondary" size="icon" className="absolute right-2 top-2" onClick={() => onPhoto(null)} aria-label="Remover foto"><X /></Button>
        </div>
      ) : (
        <button onClick={() => ref.current?.click()} className="flex w-full flex-col items-center gap-2 rounded-lg border-2 border-dashed border-border py-10 text-muted-foreground hover:bg-secondary">
          <Camera className="size-8 text-primary" /><span className="text-sm">{label}</span>
        </button>
      )}
    </div>
  );
}

const DESTINOS: Record<string, string> = { despesas: "Despesas", receitas: "Receitas", estoque: "Estoque", maquinas: "Máquinas" };

function FotoLancamento() {
  const read = useServerFn(readReceipt);
  const [photo, setPhoto] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [res, setRes] = useState<Record<string, string | number> | null>(null);
  const [done, setDone] = useState("");
  const desp = useCollection("despesas"), rec = useCollection("receitas"), est = useCollection("estoque"), maq = useCollection("maquinas");

  const reset = (p: string | null) => { setPhoto(p); setRes(null); setErr(""); setDone(""); };

  async function analisar() {
    if (!photo) return;
    setLoading(true); setErr("");
    try {
      const r = await read({ data: { image: photo, context: "" } });
      if ("error" in r && r.error) setErr(r.error); else if ("result" in r && r.result) setRes(r.result);
    } catch { setErr("Erro ao enviar a foto. Tente novamente."); }
    setLoading(false);
  }

  function confirmar() {
    if (!res) return;
    const d = String(res.destino);
    const valor = Number(res.valor) || 0, qtd = Number(res.quantidade) || 0;
    if (d === "despesas") desp.add({ descricao: res.descricao!, categoria: res.categoria!, valor, data: res.data! });
    else if (d === "receitas") rec.add({ descricao: res.descricao!, categoria: res.categoria!, valor, data: res.data! });
    else if (d === "estoque") est.add({ item: res.descricao!, quantidade: qtd, unidade: res.unidade || "un", minimo: 0, custo: qtd ? valor / qtd : valor });
    else maq.add({ nome: res.descricao!, tipo: res.categoria || "Outro", horas: 0, manutencao: "", status: "Operando" });
    setDone(DESTINOS[d] ?? d); setRes(null); setPhoto(null);
  }

  const set = (k: string, v: string | number) => setRes((r) => (r ? { ...r, [k]: v } : r));

  return (
    <div className="space-y-4">
      {done && (
        <div className="flex items-center gap-2 rounded-xl bg-success/15 p-3 text-sm text-success">
          <CheckCircle2 className="size-4" /> Lançado em {done} com sucesso.
        </div>
      )}
      <PhotoPicker label="Tirar foto de nota, recibo, boleto ou produto" photo={photo} onPhoto={reset} />
      {photo && !res && (
        <div className="rounded-xl border border-accent bg-accent/15 p-4 text-sm">
          <p className="mb-3 font-medium">Confirma que esta é a foto certa para a IA analisar?</p>
          <Button onClick={analisar} disabled={loading} className="w-full">{loading ? "Lendo a foto…" : "Sim, analisar esta foto"}</Button>
        </div>
      )}
      {err && <p className="text-sm text-destructive">{err}</p>}
      {res && (
        <div className="space-y-3 rounded-xl border-2 border-primary bg-card p-4 shadow-soft">
          <p className="text-sm text-muted-foreground">{res.resumo}</p>
          <div className="space-y-1">
            <Label>Para onde vai este lançamento?</Label>
            <select value={String(res.destino)} onChange={(e) => set("destino", e.target.value)} className="h-10 w-full rounded-md border border-input bg-background px-3 font-medium">
              {Object.entries(DESTINOS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1"><Label>Descrição</Label><Input value={String(res.descricao)} onChange={(e) => set("descricao", e.target.value)} /></div>
            <div className="space-y-1"><Label>Categoria</Label><Input value={String(res.categoria)} onChange={(e) => set("categoria", e.target.value)} /></div>
            <div className="space-y-1"><Label>Valor (R$)</Label><Input type="number" step="any" value={res.valor} onChange={(e) => set("valor", Number(e.target.value))} /></div>
            <div className="space-y-1"><Label>Data</Label><Input type="date" value={String(res.data)} onChange={(e) => set("data", e.target.value)} /></div>
            <div className="space-y-1"><Label>Qtd / unidade</Label>
              <div className="flex gap-1"><Input type="number" step="any" value={res.quantidade} onChange={(e) => set("quantidade", Number(e.target.value))} />
                <Input className="w-16" value={String(res.unidade)} onChange={(e) => set("unidade", e.target.value)} /></div>
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <Button variant="outline" onClick={() => reset(null)}>Cancelar</Button>
            <Button className="flex-1" onClick={confirmar}>Confirmar → {DESTINOS[String(res.destino)]}</Button>
          </div>
        </div>
      )}
    </div>
  );
}


function FotoPraga() {
  const diag = useServerFn(diagnosePest);
  const eventos = useCollection("eventos");
  const [photo, setPhoto] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [res, setRes] = useState<Diag | null>(null);
  const [saved, setSaved] = useState(false);

  async function analisar() {
    if (!photo) return;
    setLoading(true); setErr("");
    const ctx = JSON.stringify(readCollection("culturas").map(({ nome, area, talhao }) => ({ nome, area, talhao })));
    try {
      const r = await diag({ data: { image: photo, context: ctx } });
      if ("error" in r && r.error) setErr(r.error); else if ("result" in r && r.result) setRes(r.result);
    } catch { setErr("Erro ao enviar a foto. Tente novamente."); }
    setLoading(false);
  }

  function lembrete() {
    if (!res) return;
    const d = new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10);
    eventos.add({ titulo: `Monitorar ${res.nome}`, tipo: "Aplicação", data: d });
    setSaved(true);
  }

  return (
    <div className="space-y-4">
      <PhotoPicker label="Tirar foto da folha, fruto ou praga" photo={photo} onPhoto={(p) => { setPhoto(p); setRes(null); setErr(""); setSaved(false); }} />
      {photo && !res && (
        <div className="rounded-xl border border-accent bg-accent/15 p-4 text-sm">
          <p className="mb-3 font-medium">Confirma que esta é a foto da planta/praga para analisar?</p>
          <Button onClick={analisar} disabled={loading} className="w-full">{loading ? "Analisando…" : "Sim, identificar"}</Button>
        </div>
      )}
      {err && <p className="text-sm text-destructive">{err}</p>}
      {res && (
        <div className="space-y-4 rounded-xl border border-border bg-card p-4 shadow-soft">
          <div>
            <div className="flex flex-wrap gap-2 text-xs">
              <span className="rounded-full bg-secondary px-2 py-0.5">{res.tipo}</span>
              <span className="rounded-full bg-secondary px-2 py-0.5">Confiança {res.confianca}</span>
              <span className={`rounded-full px-2 py-0.5 ${res.urgencia === "Alta" ? "bg-destructive/15 text-destructive" : "bg-accent/30"}`}>Urgência {res.urgencia}</span>
            </div>
            <h3 className="mt-2 font-display text-2xl">{res.nome}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{res.descricao}</p>
          </div>
          <div className="rounded-lg bg-destructive/10 p-3">
            <div className="text-xs uppercase tracking-wider text-destructive">Gasto futuro estimado</div>
            <div className="font-display text-2xl text-destructive">{brl(res.custo_min)} – {brl(res.custo_max)}</div>
            <p className="mt-1 text-xs text-muted-foreground">{res.explicacao_custo}</p>
          </div>
          <Lista t="Como prevenir" items={res.prevencao} />
          <Lista t="Tratamento" items={res.tratamento} />
          <p className="text-xs text-muted-foreground">Diagnóstico por IA — confirme com um agrônomo antes de aplicar produtos.</p>
          <Button variant="outline" className="w-full" disabled={saved} onClick={lembrete}>
            {saved ? "Lembrete criado no Calendário" : "Criar lembrete de monitoramento em 7 dias"}
          </Button>
        </div>
      )}
    </div>
  );
}

function Lista({ t, items }: { t: string; items: string[] }) {
  return (
    <div>
      <h4 className="mb-1 font-medium">{t}</h4>
      <ul className="list-disc space-y-1 pl-5 text-sm">{items.map((i, k) => <li key={k}>{i}</li>)}</ul>
    </div>
  );
}

type Msg = { role: "user" | "assistant"; content: string };
const sugestoes = ["Como está minha saúde financeira?", "Onde posso reduzir custos?", "Quais itens do estoque preciso repor?"];

function Chat() {
  const ask = useServerFn(askAssistant);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);

  async function send(q: string) {
    if (!q.trim() || loading) return;
    const next = [...msgs, { role: "user" as const, content: q }];
    setMsgs(next); setText(""); setLoading(true);
    const cols: Collection[] = ["despesas", "receitas", "culturas", "eventos", "estoque", "maquinas", "metas"];
    const context = JSON.stringify(Object.fromEntries(cols.map((c) => [c, readCollection(c).slice(0, 60).map(({ id, ...r }) => r)] as [string, unknown]).concat([["clima_7_dias", cachedClima() ?? "não consultado"]]))).slice(0, 19000);
    try {
      const { reply } = await ask({ data: { messages: next.slice(-20), context } });
      setMsgs([...next, { role: "assistant", content: reply }]);
    } catch {
      setMsgs([...next, { role: "assistant", content: "Erro ao conectar. Tente novamente." }]);
    } finally { setLoading(false); }
  }

  return (
    <div className="flex h-[calc(100vh-14rem)] flex-col">
      <div className="flex-1 space-y-3 overflow-y-auto rounded-xl border border-border bg-card p-4">
        {msgs.length === 0 && (
          <div className="flex flex-col items-center gap-3 py-8 text-center">
            <Bot className="size-10 text-primary" />
            <p className="text-sm text-muted-foreground">Analiso os dados da sua fazenda para dar sugestões.</p>
            <div className="flex flex-wrap justify-center gap-2">
              {sugestoes.map((s) => <Button key={s} variant="outline" size="sm" onClick={() => send(s)}>{s}</Button>)}
            </div>
          </div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2 text-sm ${m.role === "user" ? "ml-auto bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>
            {m.content}
          </div>
        ))}
        {loading && <div className="text-sm text-muted-foreground">Pensando…</div>}
      </div>
      <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); send(text); }}>
        <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Digite sua pergunta…" />
        <Button type="submit" size="icon" disabled={loading} aria-label="Enviar"><Send /></Button>
      </form>
    </div>
  );
}
