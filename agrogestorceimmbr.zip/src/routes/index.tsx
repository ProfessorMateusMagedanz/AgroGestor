import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { PageHeader, StatCard } from "@/components/CrudPage";
import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CloudSun, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { brl, sum, useCollection, type Item } from "@/lib/store";
import { loadDemo } from "@/lib/demo";
import { alertas, carregarClima, getLocal, type Clima } from "@/lib/weather";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — AgroGestor" },
      { name: "description", content: "Visão geral financeira da sua fazenda: receitas, despesas e saldo." },
      { property: "og:title", content: "Dashboard — AgroGestor" },
      { property: "og:description", content: "Controle financeiro completo da fazenda." },
      { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

export function monthly(desp: Item[], rec: Item[]) {
  const m: Record<string, { mes: string; Receitas: number; Despesas: number }> = {};
  const put = (i: Item, k: "Receitas" | "Despesas") => {
    const mes = String(i.data || "").slice(0, 7) || "s/d";
    m[mes] ??= { mes, Receitas: 0, Despesas: 0 };
    m[mes][k] += Number(i.valor) || 0;
  };
  desp.forEach((i) => put(i, "Despesas"));
  rec.forEach((i) => put(i, "Receitas"));
  return Object.values(m).sort((a, b) => a.mes.localeCompare(b.mes)).slice(-12);
}

function Dashboard() {
  const d = useCollection("despesas").items;
  const r = useCollection("receitas").items;
  const c = useCollection("culturas").items;
  const ev = useCollection("eventos").items;
  const saldo = sum(r) - sum(d);
  const [clima, setClima] = useState<Clima | null>(null);
  useEffect(() => { carregarClima(getLocal()).then(setClima).catch(() => {}); }, []);
  const area = sum(c, "area");
  const custoHa = area ? sum(c, "custo") / area : 0;
  const prodMed = area ? c.reduce((s, i) => s + Number(i.produtividade || 0) * Number(i.area || 0), 0) / area : 0;
  const vazio = !d.length && !r.length && !c.length;
  const prox = [...ev].filter((e) => String(e.data) >= new Date().toISOString().slice(0, 10))
    .sort((a, b) => String(a.data).localeCompare(String(b.data))).slice(0, 4);

  return (
    <div>
      <PageHeader title="Bom dia, produtor" subtitle="Resumo financeiro e agronômico da sua fazenda"
        action={<Button variant={vazio ? "default" : "outline"} onClick={() => { if (vazio || confirm("Substituir seus dados pelos dados de demonstração?")) loadDemo(); }}><Sparkles /> Dados de demonstração</Button>} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Receitas" value={brl(sum(r))} tone="good" />
        <StatCard label="Despesas" value={brl(sum(d))} tone="bad" />
        <StatCard label="Saldo" value={brl(saldo)} tone={saldo >= 0 ? "good" : "bad"} />
        <StatCard label="Área plantada" value={`${area.toLocaleString("pt-BR")} ha`} />
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Talhões" value={c.length} />
        <StatCard label="Custo médio / ha" value={brl(custoHa)} />
        <StatCard label="Produtividade média" value={`${prodMed.toFixed(1)} sc/ha`} />
        <Link to="/clima" className="rounded-xl border border-border bg-card p-4 shadow-soft transition-colors hover:bg-secondary">
          <div className="flex items-center gap-1 text-xs uppercase tracking-wider text-muted-foreground"><CloudSun className="size-4" /> Clima hoje</div>
          {clima ? (<>
            <div className="mt-1 font-display text-2xl">{clima.atual.temp.toFixed(0)}°C · {clima.dias[0]?.prob}%</div>
            <div className="text-xs text-muted-foreground">{alertas(clima).length ? `${alertas(clima).length} alerta(s) na semana` : "Sem alertas"}</div>
          </>) : <div className="mt-1 text-sm text-muted-foreground">Carregando…</div>}
        </Link>
      </div>
      <div className="mt-6 grid gap-6 md:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-4 shadow-soft md:col-span-2">
          <h2 className="mb-3 font-display text-lg">Fluxo mensal</h2>
          <div className="h-56">
            <ResponsiveContainer>
              <BarChart data={monthly(d, r)}>
                <XAxis dataKey="mes" fontSize={11} />
                <Tooltip formatter={(v: number) => brl(v)} />
                <Bar dataKey="Receitas" fill="var(--success)" radius={4} />
                <Bar dataKey="Despesas" fill="var(--destructive)" radius={4} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
          <h2 className="mb-3 font-display text-lg">Próximas atividades</h2>
          {prox.length === 0 ? <p className="text-sm text-muted-foreground">Nada agendado.</p> : (
            <ul className="space-y-2 text-sm">
              {prox.map((e) => (
                <li key={e.id} className="flex justify-between gap-2">
                  <span className="truncate">{e.titulo}</span>
                  <span className="text-muted-foreground">{String(e.data).split("-").reverse().join("/")}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
