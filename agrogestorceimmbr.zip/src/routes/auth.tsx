import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Wheat } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — AgroGestor" },
      { name: "description", content: "Acesse sua conta AgroGestor para gerenciar sua fazenda." },
      { property: "og:title", content: "Entrar — AgroGestor" },
      { property: "og:description", content: "Acesse sua conta AgroGestor para gerenciar sua fazenda." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"entrar" | "criar">("entrar");
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setMsg(null);
    if (mode === "criar") {
      const { data, error } = await supabase.auth.signUp({
        email, password: senha,
        options: { emailRedirectTo: window.location.origin, data: { display_name: nome } },
      });
      if (error) setMsg(error.message);
      else if (!data.session) setMsg("Conta criada! Confira seu e-mail para confirmar o acesso.");
      else navigate({ to: "/" });
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password: senha });
      if (error) setMsg("E-mail ou senha incorretos.");
      else navigate({ to: "/" });
    }
    setBusy(false);
  }

  async function social(p: "google" | "lovable") {
    setMsg(null);
    const r = await lovable.auth.signInWithOAuth(p, { redirect_uri: window.location.origin });
    if (r.error) { setMsg("Não foi possível entrar agora."); return; }
    if (r.redirected) return;
    navigate({ to: "/" });
  }

  return (
    <div className="mx-auto mt-6 max-w-sm rounded-2xl border bg-card p-6 shadow-sm">
      <div className="mb-5 flex items-center gap-2">
        <div className="grid size-9 place-items-center rounded-lg bg-primary text-primary-foreground"><Wheat className="size-5" /></div>
        <h1 className="font-display text-2xl">{mode === "entrar" ? "Entrar" : "Criar conta"}</h1>
      </div>
      <form onSubmit={submit} className="space-y-3">
        {mode === "criar" && (
          <div><Label htmlFor="nome">Nome</Label><Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} required /></div>
        )}
        <div><Label htmlFor="email">E-mail</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
        <div><Label htmlFor="senha">Senha</Label><Input id="senha" type="password" minLength={6} value={senha} onChange={(e) => setSenha(e.target.value)} required /></div>
        {msg && <p className="text-sm text-muted-foreground">{msg}</p>}
        <Button type="submit" className="w-full" disabled={busy}>{mode === "entrar" ? "Entrar" : "Criar conta"}</Button>
      </form>
      <div className="my-4 text-center text-xs text-muted-foreground">ou</div>
      <div className="space-y-2">
        <Button variant="outline" className="w-full" onClick={() => social("google")}>Continuar com Google</Button>
        <Button variant="outline" className="w-full" onClick={() => social("lovable")}>Continuar com Lovable</Button>
      </div>
      <button className="mt-4 w-full text-center text-sm text-primary underline-offset-4 hover:underline"
        onClick={() => { setMode(mode === "entrar" ? "criar" : "entrar"); setMsg(null); }}>
        {mode === "entrar" ? "Não tem conta? Criar agora" : "Já tenho conta"}
      </button>
      <p className="mt-4 text-xs text-muted-foreground">Seus registros atuais continuam salvos neste aparelho.</p>
    </div>
  );
}
