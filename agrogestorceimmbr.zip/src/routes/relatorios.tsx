import { createFileRoute } from "@tanstack/react-router";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { Printer, Download } from "lucide-react";
import { exportCSV } from "@/lib/export";
import { Button } from "@/components/ui/button";
import { PageHeader, StatCard } from "@/components/CrudPage";
import { brl, sum, useCollection, type Item } from "@/lib/store";
import { monthly } from "./index";

export const Route = createFileRoute("/relatorios")({
  head: () => ({ meta: [
    { title: "Relatórios — AgroGestor" }, { name: "description", content: "Relatórios financeiros por categoria e por mês." },
    { property: "og:title", content: "Relatórios — AgroGestor" }, { property: "og:description", content: "Relatórios da fazenda." },
  ] }),
  component: Relatorios,
});

const colors = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
const byCat = (items: Item[]) =>
  Object.entries(items.reduce<Record<string, number>>((a, i) => ((a[String(i.categoria)] = (a[String(i.categoria)] || 0) + Number(i.valor)), a), {}))
    .map(([name, value]) => ({ name, value }));

function PieBox({ title, data }: { title: string; data: { name: string; value: number }[] }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
      <h2 className="mb-2 font-display text-lg">{title}</h2>
      {data.length === 0 ? <p className="text-sm text-muted-foreground">Sem dados.</p> : (
        <div className="h-64"><ResponsiveContainer>
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" innerRadius={45} outerRadius={80}>
              {data.map((_, i) => <Cell key={i} fill={colors[i % colors.length]} />)}
            </Pie>
            <Tooltip formatter={(v: number) => brl(v)} /><Legend wrapperStyle={{ fontSize: 11 }} />
          </PieChart>
        </ResponsiveContainer></div>
      )}
    </div>
  );
}

function Relatorios() {
  const d = useCollection("despesas").items;
  const r = useCollection("receitas").items;
  const area = sum(useCollection("culturas").items, "area");
  const saldo = sum(r) - sum(d);
  const margem = sum(r) ? (saldo / sum(r)) * 100 : 0;
  return (
    <div>
      <PageHeader title="Relatórios" subtitle="Análise financeira consolidada"
        action={
          <div className="flex gap-2 print:hidden">
            <Button variant="outline" onClick={() => exportCSV()}><Download /> Excel</Button>
            <Button variant="outline" onClick={() => window.print()}><Printer /> PDF</Button>
          </div>
        } />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Resultado" value={brl(saldo)} tone={saldo >= 0 ? "good" : "bad"} />
        <StatCard label="Margem" value={`${margem.toFixed(1)}%`} />
        <StatCard label="Área total" value={`${area} ha`} />
        <StatCard label="Custo / ha" value={area ? brl(sum(d) / area) : "—"} />
      </div>
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <PieBox title="Despesas por categoria" data={byCat(d)} />
        <PieBox title="Receitas por categoria" data={byCat(r)} />
      </div>
      <div className="mt-6 overflow-x-auto rounded-xl border border-border bg-card p-4 shadow-soft">
        <h2 className="mb-3 font-display text-lg">Resultado mensal</h2>
        <table className="w-full text-sm">
          <thead className="text-left text-muted-foreground"><tr><th className="py-1">Mês</th><th>Receitas</th><th>Despesas</th><th>Saldo</th></tr></thead>
          <tbody>
            {monthly(d, r).map((m) => (
              <tr key={m.mes} className="border-t border-border">
                <td className="py-2">{m.mes}</td><td className="text-success">{brl(m.Receitas)}</td>
                <td className="text-destructive">{brl(m.Despesas)}</td><td>{brl(m.Receitas - m.Despesas)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
