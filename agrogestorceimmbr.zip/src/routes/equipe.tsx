import { useCallback, useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Bell, Pencil, Plus, Trash2, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { PageHeader, StatCard } from "@/components/CrudPage";
import { addTo, brl } from "@/lib/store";
import { downloadCSV } from "@/lib/export";
import { saldoDoMes, prazoProximo } from "@/lib/equipe";

export const Route = createFileRoute("/equipe")({
  head: () => ({ meta: [
    { title: "Equipe — AgroGestor" },
    { name: "description", content: "Funcionários, tarefas e pagamentos da fazenda." },
    { property: "og:title", content: "Equipe — AgroGestor" },
    { property: "og:description", content: "Delegue tarefas e controle pagamentos da equipe." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: Equipe,
});

type Emp = Tables<"employees">; type Task = Tables<"tasks">; type Pay = Tables<"payments">;
const STATUS = ["Pendente", "Em andamento", "Feita"] as const;
const hoje = () => new Date().toISOString().slice(0, 10);
const fmt = (d?: string | null) => (d ? d.slice(0, 10).split("-").reverse().join("/") : "—");
const prioTone = (p: string) => (p === "Alta" ? "destructive" : p === "Média" ? "secondary" : "outline") as "destructive" | "secondary" | "outline";

function Equipe() {
  const [state, setState] = useState<"loading" | "out" | "none" | "admin" | "employee">("loading");
  const [propertyId, setPropertyId] = useState("");
  const load = useCallback(async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return setState("out");
    await supabase.rpc("claim_employee");
    const { data: props } = await supabase.from("properties").select("id").eq("owner_id", u.user.id).limit(1);
    if (props?.[0]) { setPropertyId(props[0].id); return setState("admin"); }
    const { data: me } = await supabase.from("employees").select("id").eq("user_id", u.user.id).limit(1);
    setState(me?.length ? "employee" : "none");
  }, []);
  useEffect(() => {
    load();
    const { data } = supabase.auth.onAuthStateChange((e) => { if (e === "SIGNED_IN" || e === "SIGNED_OUT") load(); });
    return () => data.subscription.unsubscribe();
  }, [load]);

  if (state === "loading") return <p className="text-sm text-muted-foreground">Carregando…</p>;
  if (state === "out") return (
    <div><PageHeader title="Equipe" subtitle="Funcionários, tarefas e pagamentos" />
      <Card><p className="mb-3 text-sm">Entre na sua conta para gerenciar sua equipe. Funcionários também entram por aqui para ver as próprias tarefas.</p><Button asChild><Link to="/auth">Entrar</Link></Button></Card></div>
  );
  if (state === "none") return (
    <div><PageHeader title="Equipe" subtitle="Funcionários, tarefas e pagamentos" />
      <Card>
        <p className="mb-3 text-sm">Você ainda não tem uma fazenda cadastrada. Se você é o administrador, crie a sua. Se é funcionário, peça ao administrador para cadastrar o seu e-mail e entre de novo.</p>
        <form className="flex flex-wrap gap-2" onSubmit={async (e) => {
          e.preventDefault(); const name = String(new FormData(e.currentTarget).get("nome") || "").trim();
          if (!name) return;
          const { data: u } = await supabase.auth.getUser();
          const { error } = await supabase.from("properties").insert({ name, owner_id: u.user!.id });
          if (error) return void toast.error("Não foi possível criar a fazenda.");
          toast.success("Fazenda criada."); load();
        }}><Input name="nome" placeholder="Nome da fazenda" className="max-w-xs" required /><Button>Criar fazenda</Button></form>
      </Card></div>
  );
  return state === "admin" ? <Admin propertyId={propertyId} /> : <Funcionario />;
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`rounded-xl border border-border bg-card p-4 shadow-soft ${className}`}>{children}</div>;
}
function Empty({ text }: { text: string }) {
  return <div className="rounded-xl border border-dashed border-border bg-card p-8 text-center text-sm text-muted-foreground"><Users className="mx-auto mb-2 size-6" />{text}</div>;
}

// ---------------- Formulário genérico ----------------
type F = { name: string; label: string; type?: "text" | "number" | "date" | "email" | "select" | "month"; options?: { value: string; label: string }[] | readonly string[]; required?: boolean };
function FormDialog({ trigger, title, fields, initial, onSubmit }: { trigger: React.ReactNode; title: string; fields: F[]; initial?: Record<string, unknown>; onSubmit: (d: Record<string, string>) => Promise<string | undefined> }) {
  const [open, setOpen] = useState(false); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); setErr(""); }}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
        <form className="grid gap-3 sm:grid-cols-2" onSubmit={async (e) => {
          e.preventDefault(); const fd = new FormData(e.currentTarget); const d: Record<string, string> = {};
          fields.forEach((f) => (d[f.name] = String(fd.get(f.name) ?? "").trim()));
          setBusy(true); const r = await onSubmit(d); setBusy(false);
          if (r) return setErr(r); setOpen(false);
        }}>
          {fields.map((f) => {
            const dv = String(initial?.[f.name] ?? "");
            return <div key={f.name} className="space-y-1"><Label htmlFor={`f-${f.name}`}>{f.label}{f.required && " *"}</Label>
              {f.type === "select" ? (
                <select id={`f-${f.name}`} name={f.name} defaultValue={dv} required={f.required} className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm">
                  {!f.required && <option value="">—</option>}
                  {f.options?.map((o) => typeof o === "string" ? <option key={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              ) : <Input id={`f-${f.name}`} name={f.name} type={f.type ?? "text"} step="any" min={f.type === "number" ? 0 : undefined} defaultValue={dv} required={f.required} />}
            </div>;
          })}
          {err && <p className="text-sm text-destructive sm:col-span-2">{err}</p>}
          <Button disabled={busy} className="sm:col-span-2">{busy ? "Salvando…" : "Salvar"}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ---------------- Administrador ----------------
function Admin({ propertyId }: { propertyId: string }) {
  const [emps, setEmps] = useState<Emp[]>([]); const [tasks, setTasks] = useState<Task[]>([]); const [pays, setPays] = useState<Pay[]>([]);
  const [perfil, setPerfil] = useState<string | null>(null);
  const reload = useCallback(async () => {
    const [e, t, p] = await Promise.all([
      supabase.from("employees").select("*").eq("property_id", propertyId).order("name"),
      supabase.from("tasks").select("*").eq("property_id", propertyId).order("created_at", { ascending: false }),
      supabase.from("payments").select("*").eq("property_id", propertyId).order("month", { ascending: false }),
    ]);
    if (e.error || t.error || p.error) toast.error("Erro ao carregar dados da equipe.");
    setEmps(e.data ?? []); setTasks(t.data ?? []); setPays(p.data ?? []);
  }, [propertyId]);
  useEffect(() => {
    reload();
    const ch = supabase.channel(`tasks-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "tasks" }, (pl) => {
        const n = pl.new as Task; const o = pl.old as Partial<Task>;
        if (n.status === "Feita" && o.status !== "Feita") toast.success(`Tarefa concluída: ${n.title}`);
        reload();
      }).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [reload]);

  const nome = (id: string) => emps.find((e) => e.id === id)?.name ?? "—";
  const optEmp = emps.filter((e) => e.active).map((e) => ({ value: e.id, label: e.name }));
  const mes = hoje().slice(0, 7);
  const pagosMes = pays.filter((p) => p.month === mes && p.status === "Pago");
  const pendMes = pays.filter((p) => p.month === mes && p.status === "Pendente");
  const proximas = tasks.filter((t) => t.status !== "Feita" && prazoProximo(t.due_date, hoje()));
  const setores = [...new Set(emps.map((e) => e.sector || "Sem setor"))];

  const empFields: F[] = [
    { name: "name", label: "Nome", required: true }, { name: "email", label: "E-mail (para o acesso dele)", type: "email" },
    { name: "phone", label: "Telefone" }, { name: "job_title", label: "Função", required: true },
    { name: "sector", label: "Setor" }, { name: "hired_at", label: "Data de contratação", type: "date" },
    { name: "salary", label: "Salário (R$)", type: "number", required: true },
  ];
  const saveEmp = (id?: string) => async (d: Record<string, string>) => {
    const row = { name: d.name!, email: d.email || null, phone: d.phone ?? "", job_title: d.job_title ?? "", sector: d.sector ?? "", hired_at: d.hired_at || null, salary: Number(d.salary) || 0 };
    const { error } = id ? await supabase.from("employees").update(row).eq("id", id) : await supabase.from("employees").insert({ ...row, property_id: propertyId });
    if (error) return error.code === "23505" ? "Já existe um funcionário com esse e-mail." : "Não foi possível salvar.";
    toast.success(id ? "Cadastro atualizado." : "Funcionário cadastrado."); reload(); return undefined;
  };
  const taskFields: F[] = [
    { name: "title", label: "Título", required: true }, { name: "employee_id", label: "Responsável", type: "select", options: optEmp, required: true },
    { name: "due_date", label: "Prazo", type: "date" }, { name: "priority", label: "Prioridade", type: "select", options: ["Baixa", "Média", "Alta"], required: true },
    { name: "description", label: "Descrição" },
  ];
  const saveTask = (id?: string) => async (d: Record<string, string>) => {
    const row = { title: d.title!, employee_id: d.employee_id!, due_date: d.due_date || null, priority: d.priority!, description: d.description ?? "" };
    const { error } = id ? await supabase.from("tasks").update(row).eq("id", id) : await supabase.from("tasks").insert({ ...row, property_id: propertyId });
    if (error) return "Não foi possível salvar a tarefa.";
    toast.success(id ? "Tarefa atualizada." : `Tarefa enviada para ${nome(row.employee_id)}.`); reload(); return undefined;
  };
  async function marcarPago(p: Pay) {
    const { error } = await supabase.from("payments").update({ status: "Pago", paid_at: hoje() }).eq("id", p.id);
    if (error) return toast.error("Não foi possível atualizar.");
    if (p.kind !== "Desconto") addTo("despesas", { descricao: `${p.kind} — ${nome(p.employee_id)} (${p.month})`, categoria: "Mão de obra", valor: Number(p.amount), data: hoje(), pagamentoId: p.id });
    toast.success("Pagamento marcado como pago e lançado em Despesas."); reload();
  }

  const porStatus = STATUS.map((s) => ({ name: s, total: tasks.filter((t) => t.status === s).length }));
  const porFunc = emps.map((e) => ({ name: e.name.split(" ")[0], feitas: tasks.filter((t) => t.employee_id === e.id && t.status === "Feita").length, abertas: tasks.filter((t) => t.employee_id === e.id && t.status !== "Feita").length }));
  const empPerfil = emps.find((e) => e.id === perfil);

  return (
    <div>
      <PageHeader title="Equipe" subtitle="Funcionários, tarefas e pagamentos" />
      <Tabs defaultValue="painel">
        <TabsList className="mb-4 flex h-auto flex-wrap justify-start">
          <TabsTrigger value="painel">Painel</TabsTrigger><TabsTrigger value="func">Funcionários</TabsTrigger>
          <TabsTrigger value="tarefas">Tarefas</TabsTrigger><TabsTrigger value="pag">Pagamentos</TabsTrigger>
        </TabsList>

        <TabsContent value="painel" className="space-y-4">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <StatCard label="Funcionários" value={emps.filter((e) => e.active).length} />
            <StatCard label="Tarefas pendentes" value={tasks.filter((t) => t.status === "Pendente").length} />
            <StatCard label="Em andamento" value={tasks.filter((t) => t.status === "Em andamento").length} />
            <StatCard label="Concluídas" value={tasks.filter((t) => t.status === "Feita").length} tone="good" />
            <StatCard label="Pago no mês" value={brl(pagosMes.reduce((s, p) => s + (p.kind === "Desconto" ? -1 : 1) * Number(p.amount), 0))} tone="good" />
            <StatCard label="Pendente no mês" value={brl(pendMes.reduce((s, p) => s + (p.kind === "Desconto" ? -1 : 1) * Number(p.amount), 0))} tone="bad" />
            <StatCard label="Folha mensal" value={brl(emps.filter((e) => e.active).reduce((s, e) => s + Number(e.salary), 0))} />
            <StatCard label="Setores" value={setores.length} />
          </div>
          {proximas.length > 0 && <Card><div className="mb-1 flex items-center gap-2 font-medium"><Bell className="size-4" /> Prazos próximos ou atrasados</div>
            {proximas.map((t) => <div key={t.id} className="text-sm">{fmt(t.due_date)} · {t.title} · {nome(t.employee_id)}{t.due_date! < hoje() && <span className="ml-1 text-destructive">atrasada</span>}</div>)}</Card>}
          <div className="grid gap-4 md:grid-cols-2">
            <Card><h3 className="mb-2 font-display text-lg">Tarefas por status</h3><div className="h-52"><ResponsiveContainer><BarChart data={porStatus}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="name" fontSize={11} /><YAxis allowDecimals={false} fontSize={11} /><Tooltip /><Bar dataKey="total" fill="var(--primary)" radius={4} /></BarChart></ResponsiveContainer></div></Card>
            <Card><h3 className="mb-2 font-display text-lg">Produtividade por funcionário</h3>{porFunc.length ? <div className="h-52"><ResponsiveContainer><BarChart data={porFunc}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="name" fontSize={11} /><YAxis allowDecimals={false} fontSize={11} /><Tooltip /><Bar dataKey="feitas" name="Feitas" fill="var(--success)" radius={4} /><Bar dataKey="abertas" name="Abertas" fill="var(--muted-foreground)" radius={4} /></BarChart></ResponsiveContainer></div> : <p className="text-sm text-muted-foreground">Sem funcionários ainda.</p>}</Card>
          </div>
        </TabsContent>

        <TabsContent value="func">
          <div className="mb-4"><FormDialog title="Novo funcionário" fields={empFields} trigger={<Button><Plus /> Novo funcionário</Button>} onSubmit={saveEmp()} /></div>
          <p className="mb-3 text-xs text-muted-foreground">Para o funcionário acessar pelo celular, cadastre o e-mail dele. Ele cria a conta em “Entrar” com esse mesmo e-mail e abre a página Equipe.</p>
          {!emps.length ? <Empty text="Nenhum funcionário cadastrado." /> : setores.map((s) => (
            <div key={s} className="mb-4"><h3 className="mb-2 text-sm font-medium text-muted-foreground">{s}</h3>
              <ul className="space-y-2">{emps.filter((e) => (e.sector || "Sem setor") === s).map((e) => (
                <li key={e.id} className="flex items-center gap-2 rounded-xl border border-border bg-card p-3 text-sm shadow-soft">
                  <button className="min-w-0 flex-1 text-left" onClick={() => setPerfil(e.id)}><b>{e.name}</b> <span className="text-muted-foreground">· {e.job_title} · {brl(Number(e.salary))} · {e.phone || "sem telefone"}</span> {e.user_id ? <Badge variant="secondary">com acesso</Badge> : e.email ? <Badge variant="outline">aguardando cadastro</Badge> : null}</button>
                  <FormDialog title={`Editar ${e.name}`} fields={empFields} initial={e} trigger={<Button variant="ghost" size="icon" aria-label="Editar"><Pencil /></Button>} onSubmit={saveEmp(e.id)} />
                  <Button variant="ghost" size="icon" aria-label="Excluir" onClick={async () => {
                    if (!confirm(`Excluir ${e.name}? As tarefas e pagamentos dele também serão apagados.`)) return;
                    const { error } = await supabase.from("employees").delete().eq("id", e.id);
                    if (error) toast.error("Não foi possível excluir."); else { toast.success("Funcionário excluído."); reload(); }
                  }}><Trash2 className="text-muted-foreground" /></Button>
                </li>))}</ul></div>))}
        </TabsContent>

        <TabsContent value="tarefas"><TarefasAdmin tasks={tasks} nome={nome} optEmp={optEmp} taskFields={taskFields} saveTask={saveTask} reload={reload} /></TabsContent>

        <TabsContent value="pag"><PagamentosAdmin pays={pays} emps={emps} nome={nome} optEmp={optEmp} propertyId={propertyId} reload={reload} marcarPago={marcarPago} /></TabsContent>
      </Tabs>

      <Dialog open={!!empPerfil} onOpenChange={(o) => !o && setPerfil(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          {empPerfil && <>
            <DialogHeader><DialogTitle>{empPerfil.name}</DialogTitle></DialogHeader>
            <p className="text-sm text-muted-foreground">{empPerfil.job_title} · {empPerfil.sector || "Sem setor"} · desde {fmt(empPerfil.hired_at)} · {empPerfil.phone} · {empPerfil.email}</p>
            <p className="text-sm">Salário: <b>{brl(Number(empPerfil.salary))}</b></p>
            <h4 className="mt-3 font-medium">Tarefas concluídas</h4>
            <ul className="text-sm">{tasks.filter((t) => t.employee_id === empPerfil.id && t.status === "Feita").map((t) => <li key={t.id}>{fmt(t.completed_at)} · {t.title}</li>)}</ul>
            <h4 className="mt-3 font-medium">Tarefas abertas</h4>
            <ul className="text-sm">{tasks.filter((t) => t.employee_id === empPerfil.id && t.status !== "Feita").map((t) => <li key={t.id}>{t.title} · {t.status} · prazo {fmt(t.due_date)}</li>)}</ul>
            <h4 className="mt-3 font-medium">Pagamentos</h4>
            <ul className="text-sm">{pays.filter((p) => p.employee_id === empPerfil.id).map((p) => <li key={p.id}>{p.month} · {p.kind} · {brl(Number(p.amount))} · {p.status}{p.paid_at ? ` em ${fmt(p.paid_at)}` : ""}{p.notes ? ` · ${p.notes}` : ""}</li>)}</ul>
          </>}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function TarefasAdmin({ tasks, nome, optEmp, taskFields, saveTask, reload }: { tasks: Task[]; nome: (id: string) => string; optEmp: { value: string; label: string }[]; taskFields: F[]; saveTask: (id?: string) => (d: Record<string, string>) => Promise<string | undefined>; reload: () => void }) {
  const [st, setSt] = useState(""); const [emp, setEmp] = useState("");
  const f = tasks.filter((t) => (!st || t.status === st) && (!emp || t.employee_id === emp));
  return (<>
    <div className="mb-4 flex flex-wrap gap-2">
      <FormDialog title="Nova tarefa" fields={taskFields} trigger={<Button disabled={!optEmp.length}><Plus /> Nova tarefa</Button>} onSubmit={saveTask()} />
      <select value={st} onChange={(e) => setSt(e.target.value)} className="h-9 rounded-md border border-input bg-background px-3 text-sm"><option value="">Todos os status</option>{STATUS.map((s) => <option key={s}>{s}</option>)}</select>
      <select value={emp} onChange={(e) => setEmp(e.target.value)} className="h-9 rounded-md border border-input bg-background px-3 text-sm"><option value="">Todos os funcionários</option>{optEmp.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
    </div>
    <p className="mb-3 text-xs text-muted-foreground">O status muda aqui automaticamente quando o funcionário atualiza pelo celular.</p>
    {!f.length ? <Empty text={optEmp.length ? "Nenhuma tarefa." : "Cadastre um funcionário para delegar tarefas."} /> :
      <ul className="space-y-2">{f.map((t) => (
        <li key={t.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-border bg-card p-3 text-sm shadow-soft">
          <div className="min-w-0 flex-1"><b>{t.title}</b> <Badge variant={prioTone(t.priority)}>{t.priority}</Badge> <span className="text-muted-foreground">· {nome(t.employee_id)} · prazo {fmt(t.due_date)}{t.description ? " · " + t.description : ""}</span></div>
          <Badge variant={t.status === "Feita" ? "default" : "outline"}>{t.status}</Badge>
          <FormDialog title="Editar tarefa" fields={taskFields} initial={t} trigger={<Button variant="ghost" size="icon" aria-label="Editar"><Pencil /></Button>} onSubmit={saveTask(t.id)} />
          <Button variant="ghost" size="icon" aria-label="Excluir" onClick={async () => { if (!confirm("Excluir tarefa?")) return; await supabase.from("tasks").delete().eq("id", t.id); reload(); }}><Trash2 className="text-muted-foreground" /></Button>
        </li>))}</ul>}
  </>);
}

function PagamentosAdmin({ pays, emps, nome, optEmp, propertyId, reload, marcarPago }: { pays: Pay[]; emps: Emp[]; nome: (id: string) => string; optEmp: { value: string; label: string }[]; propertyId: string; reload: () => void; marcarPago: (p: Pay) => void }) {
  const [mes, setMes] = useState(hoje().slice(0, 7));
  const doMes = pays.filter((p) => p.month === mes);
  const totais = saldoDoMes(doMes);
  async function gerarFolha() {
    const ja = new Set(doMes.filter((p) => p.kind === "Salário").map((p) => p.employee_id));
    const novos = emps.filter((e) => e.active && !ja.has(e.id) && Number(e.salary) > 0)
      .map((e) => ({ property_id: propertyId, employee_id: e.id, month: mes, kind: "Salário", amount: Number(e.salary), status: "Pendente" }));
    if (!novos.length) return void toast.info("Todos os salários deste mês já foram lançados.");
    const { error } = await supabase.from("payments").insert(novos);
    if (error) toast.error("Não foi possível gerar a folha."); else { toast.success(`${novos.length} salário(s) lançados como pendentes.`); reload(); }
  }
  return (<>
    <div className="mb-4 flex flex-wrap items-center gap-2">
      <Input type="month" value={mes} onChange={(e) => setMes(e.target.value)} className="w-44" aria-label="Mês" />
      <Button variant="outline" onClick={gerarFolha} disabled={!emps.length}>Gerar salários do mês</Button>
      <FormDialog title="Lançar pagamento, adiantamento ou desconto" trigger={<Button disabled={!optEmp.length}><Plus /> Novo lançamento</Button>}
        fields={[{ name: "employee_id", label: "Funcionário", type: "select", options: optEmp, required: true }, { name: "month", label: "Mês de referência", type: "month", required: true }, { name: "kind", label: "Tipo", type: "select", options: ["Salário", "Adiantamento", "Desconto", "Bônus"], required: true }, { name: "amount", label: "Valor (R$)", type: "number", required: true }, { name: "status", label: "Situação", type: "select", options: ["Pendente", "Pago"], required: true }, { name: "paid_at", label: "Data do pagamento", type: "date" }, { name: "notes", label: "Observações" }]}
        initial={{ month: mes }}
        onSubmit={async (d) => {
          if (!(Number(d.amount) > 0)) return "Informe um valor maior que zero.";
          const row = { property_id: propertyId, employee_id: d.employee_id!, month: d.month!, kind: d.kind!, amount: Number(d.amount), status: d.status!, paid_at: d.status === "Pago" ? d.paid_at || hoje() : null, notes: d.notes ?? "" };
          const { error } = await supabase.from("payments").insert(row);
          if (error) return "Não foi possível salvar.";
          if (row.status === "Pago" && row.kind !== "Desconto") addTo("despesas", { descricao: `${row.kind} — ${nome(row.employee_id)} (${row.month})`, categoria: "Mão de obra", valor: row.amount, data: row.paid_at!, });
          toast.success("Lançamento salvo."); reload(); return undefined;
        }} />
      <Button variant="outline" disabled={!doMes.length} onClick={() => downloadCSV(`folha-${mes}.csv`, doMes.map((p) => ({ Funcionário: nome(p.employee_id), Tipo: p.kind, Valor: Number(p.amount), Situação: p.status, "Pago em": p.paid_at ?? "", Observações: p.notes })))}>Relatório (Excel)</Button>
    </div>
    <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
      <StatCard label="Total líquido" value={brl(totais.liquido)} /><StatCard label="Pago" value={brl(totais.pago)} tone="good" />
      <StatCard label="Pendente" value={brl(totais.pendente)} tone="bad" /><StatCard label="Descontos" value={brl(totais.descontos)} />
    </div>
    {!doMes.length ? <Empty text="Nenhum lançamento neste mês." /> :
      <ul className="space-y-2">{doMes.map((p) => (
        <li key={p.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-border bg-card p-3 text-sm shadow-soft">
          <div className="min-w-0 flex-1"><b>{nome(p.employee_id)}</b> <span className="text-muted-foreground">· {p.kind} · {p.paid_at ? `pago em ${fmt(p.paid_at)}` : "não pago"}{p.notes ? " · " + p.notes : ""}</span></div>
          <span className={`font-display text-lg ${p.kind === "Desconto" ? "text-destructive" : ""}`}>{p.kind === "Desconto" ? "−" : ""}{brl(Number(p.amount))}</span>
          {p.status === "Pago" ? <Badge>Pago</Badge> : <Button size="sm" onClick={() => marcarPago(p)}>Marcar como pago</Button>}
          <Button variant="ghost" size="icon" aria-label="Excluir" onClick={async () => { if (!confirm("Excluir lançamento?")) return; await supabase.from("payments").delete().eq("id", p.id); reload(); }}><Trash2 className="text-muted-foreground" /></Button>
        </li>))}</ul>}
  </>);
}

// ---------------- Área do funcionário ----------------
function Funcionario() {
  const [me, setMe] = useState<Emp[]>([]); const [tasks, setTasks] = useState<Task[]>([]); const [pays, setPays] = useState<Pay[]>([]);
  const reload = useCallback(async () => {
    const { data: u } = await supabase.auth.getUser();
    const { data: e } = await supabase.from("employees").select("*").eq("user_id", u.user!.id);
    const ids = (e ?? []).map((x) => x.id);
    const [t, p] = await Promise.all([
      supabase.from("tasks").select("*").in("employee_id", ids).order("due_date", { ascending: true, nullsFirst: false }),
      supabase.from("payments").select("*").in("employee_id", ids).order("month", { ascending: false }),
    ]);
    setMe(e ?? []); setTasks(t.data ?? []); setPays(p.data ?? []);
  }, []);
  useEffect(() => {
    reload();
    const ch = supabase.channel(`mytasks-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "tasks" }, (pl) => { toast.info(`Nova tarefa: ${(pl.new as Task).title}`); reload(); })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [reload]);
  async function mudar(t: Task, s: string) {
    const { error } = await supabase.rpc("set_my_task_status", { t: t.id, s });
    if (error) return toast.error("Não foi possível atualizar.");
    toast.success(s === "Feita" ? "Tarefa concluída!" : "Status atualizado."); reload();
  }
  const abertas = tasks.filter((t) => t.status !== "Feita");
  const novas = abertas.filter((t) => !t.seen_by_employee);
  const proximas = abertas.filter((t) => prazoProximo(t.due_date, hoje()));
  const m = me[0];
  return (
    <div>
      <PageHeader title={`Olá, ${m?.name.split(" ")[0] ?? ""}`} subtitle={`${m?.job_title ?? ""} — suas tarefas e pagamentos`} />
      {(novas.length > 0 || proximas.length > 0) && <Card className="mb-4"><div className="mb-1 flex items-center gap-2 font-medium"><Bell className="size-4" /> Avisos</div>
        {novas.map((t) => <div key={t.id} className="text-sm">Nova tarefa: {t.title}</div>)}
        {proximas.map((t) => <div key={"p" + t.id} className="text-sm">Prazo {t.due_date! < hoje() ? "vencido" : "próximo"}: {t.title} ({fmt(t.due_date)})</div>)}</Card>}
      <Tabs defaultValue="tarefas">
        <TabsList className="mb-4"><TabsTrigger value="tarefas">Minhas tarefas ({abertas.length})</TabsTrigger><TabsTrigger value="hist">Histórico</TabsTrigger><TabsTrigger value="pag">Pagamentos</TabsTrigger></TabsList>
        <TabsContent value="tarefas">
          {!abertas.length ? <Empty text="Nenhuma tarefa aberta. Bom trabalho!" /> :
            <ul className="space-y-3">{abertas.map((t) => (
              <li key={t.id} className="rounded-xl border border-border bg-card p-4 shadow-soft">
                <div className="flex flex-wrap items-center gap-2"><b>{t.title}</b><Badge variant={prioTone(t.priority)}>{t.priority}</Badge><span className="text-sm text-muted-foreground">prazo {fmt(t.due_date)}</span></div>
                {t.description && <p className="mt-1 text-sm">{t.description}</p>}
                <div className="mt-3 grid grid-cols-3 gap-2">{STATUS.map((s) => <Button key={s} size="sm" variant={t.status === s ? "default" : "outline"} onClick={() => t.status !== s && mudar(t, s)}>{s}</Button>)}</div>
              </li>))}</ul>}
        </TabsContent>
        <TabsContent value="hist">
          {!tasks.some((t) => t.status === "Feita") ? <Empty text="Nenhuma tarefa concluída ainda." /> :
            <ul className="space-y-2 text-sm">{tasks.filter((t) => t.status === "Feita").map((t) => <li key={t.id} className="rounded-xl border border-border bg-card p-3">{fmt(t.completed_at)} · {t.title}</li>)}</ul>}
        </TabsContent>
        <TabsContent value="pag">
          {!pays.length ? <Empty text="Nenhum pagamento registrado." /> :
            <ul className="space-y-2 text-sm">{pays.map((p) => <li key={p.id} className="flex items-center gap-2 rounded-xl border border-border bg-card p-3"><div className="flex-1">{p.month} · {p.kind}{p.notes ? ` · ${p.notes}` : ""}</div><b>{p.kind === "Desconto" ? "−" : ""}{brl(Number(p.amount))}</b><Badge variant={p.status === "Pago" ? "default" : "outline"}>{p.status}</Badge></li>)}</ul>}
        </TabsContent>
      </Tabs>
    </div>
  );
}
// keep for type inference
export type { Emp };
void useMemo;
