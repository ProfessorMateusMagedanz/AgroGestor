import { readCollection, type Collection } from "./store";

const SECOES: [Collection, string][] = [
  ["receitas", "RECEITAS"], ["despesas", "DESPESAS"], ["culturas", "CULTURAS"], ["estoque", "ESTOQUE"],
  ["maquinas", "MÁQUINAS"], ["metas", "METAS"], ["eventos", "CALENDÁRIO"],
];

const cell = (v: unknown) => {
  const s = typeof v === "number" ? String(v).replace(".", ",") : String(v ?? "");
  return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

// Gera um arquivo .csv (abre no Excel) com todas as seções.
export function exportCSV() {
  const lines: string[] = [`Relatório AgroGestor;${new Date().toLocaleDateString("pt-BR")}`, ""];
  for (const [c, t] of SECOES) {
    const items = readCollection(c).map(({ id, ...r }) => r);
    lines.push(t);
    if (items.length) {
      const cols = Object.keys(items[0]!);
      lines.push(cols.join(";"));
      items.forEach((i) => lines.push(cols.map((k) => cell(i[k])).join(";")));
    } else lines.push("Sem registros");
    lines.push("");
  }
  const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `agrogestor-relatorio-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

/** Exporta uma tabela qualquer (lista de linhas) como .csv para Excel. */
export function downloadCSV(nome: string, rows: Record<string, unknown>[]) {
  const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))];
  const lines = [cols.join(";"), ...rows.map((r) => cols.map((k) => cell(r[k])).join(";"))];
  const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = nome.replace(/[^\w.-]+/g, "-");
  a.click();
}
