export type Local = { nome: string; lat: number; lon: number };
export type Dia = { data: string; max: number; min: number; chuva: number; prob: number; vento: number; codigo: number };
export type Clima = { local: Local; atual: { temp: number; umidade: number; vento: number; codigo: number }; dias: Dia[] };

const LKEY = "agrogestor:local";
const CKEY = "agrogestor:clima";
export const DEFAULT_LOCAL: Local = { nome: "Sorriso, MT", lat: -12.5425, lon: -55.7211 };

export function getLocal(): Local {
  try { return JSON.parse(localStorage.getItem(LKEY) || "") as Local; } catch { return DEFAULT_LOCAL; }
}
export const setLocal = (l: Local) => localStorage.setItem(LKEY, JSON.stringify(l));
export function cachedClima(): Clima | null {
  try { return JSON.parse(localStorage.getItem(CKEY) || "null"); } catch { return null; }
}

export async function buscarCidade(q: string): Promise<Local[]> {
  const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=5&language=pt&countryCode=BR`);
  const j = await r.json();
  return (j.results ?? []).map((x: { name: string; admin1?: string; latitude: number; longitude: number }) =>
    ({ nome: `${x.name}${x.admin1 ? ", " + x.admin1 : ""}`, lat: x.latitude, lon: x.longitude }));
}

export async function carregarClima(local: Local): Promise<Clima> {
  const u = `https://api.open-meteo.com/v1/forecast?latitude=${local.lat}&longitude=${local.lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,weather_code&timezone=America%2FSao_Paulo&forecast_days=7`;
  const j = await (await fetch(u)).json();
  const d = j.daily;
  const c: Clima = {
    local,
    atual: { temp: j.current.temperature_2m, umidade: j.current.relative_humidity_2m, vento: j.current.wind_speed_10m, codigo: j.current.weather_code },
    dias: d.time.map((t: string, k: number) => ({
      data: t, max: d.temperature_2m_max[k], min: d.temperature_2m_min[k], chuva: d.precipitation_sum[k],
      prob: d.precipitation_probability_max[k] ?? 0, vento: d.wind_speed_10m_max[k], codigo: d.weather_code[k],
    })),
  };
  localStorage.setItem(CKEY, JSON.stringify(c));
  return c;
}

export function descricao(code: number) {
  if (code === 0) return "Céu limpo";
  if (code <= 3) return "Parcialmente nublado";
  if (code <= 48) return "Neblina";
  if (code <= 67) return "Chuva";
  if (code <= 77) return "Neve";
  if (code <= 82) return "Pancadas de chuva";
  return "Tempestade";
}

export type Alerta = { nivel: "alto" | "medio"; titulo: string; texto: string };

export function alertas(c: Clima): Alerta[] {
  const a: Alerta[] = [];
  const d = c.dias;
  const tempest = d.find((x) => x.codigo >= 95);
  if (tempest) a.push({ nivel: "alto", titulo: "Risco de tempestade", texto: `Previsão de tempestade em ${fmtD(tempest.data)}. Recolha máquinas e evite operações a campo.` });
  const forte = d.find((x) => x.chuva >= 30);
  if (forte) a.push({ nivel: "alto", titulo: "Chuva forte", texto: `${forte.chuva.toFixed(0)} mm previstos em ${fmtD(forte.data)}. Risco de erosão e atraso na colheita.` });
  const calor = d.find((x) => x.max >= 35);
  if (calor) a.push({ nivel: "medio", titulo: "Calor intenso", texto: `Máxima de ${calor.max.toFixed(0)}°C em ${fmtD(calor.data)}. Estresse hídrico nas lavouras e no gado.` });
  const geada = d.find((x) => x.min <= 3);
  if (geada) a.push({ nivel: "alto", titulo: "Risco de geada", texto: `Mínima de ${geada.min.toFixed(0)}°C em ${fmtD(geada.data)}. Proteja culturas sensíveis.` });
  const vento = d.find((x) => x.vento >= 40);
  if (vento) a.push({ nivel: "medio", titulo: "Ventos fortes", texto: `Rajadas de ${vento.vento.toFixed(0)} km/h em ${fmtD(vento.data)}. Não pulverize.` });
  const seco = d.filter((x) => x.prob < 20).length;
  if (seco >= 6) a.push({ nivel: "medio", titulo: "Período seco", texto: "Quase sem chuva na semana. Avalie irrigação e adie plantio sem umidade no solo." });
  return a;
}

export function recomendacoes(c: Clima): string[] {
  const r: string[] = [];
  const janelas = c.dias.filter((x) => x.prob < 30 && x.vento < 20 && x.max < 32);
  if (janelas.length) r.push(`Melhores dias para pulverizar: ${janelas.slice(0, 3).map((x) => fmtD(x.data)).join(", ")} (pouca chuva e vento fraco).`);
  else r.push("Sem boa janela de pulverização na semana: vento, calor ou chuva acima do ideal.");
  const chuva3 = c.dias.slice(0, 3).reduce((s, x) => s + x.chuva, 0);
  if (chuva3 >= 20) r.push(`Boa umidade prevista nos próximos 3 dias (${chuva3.toFixed(0)} mm): favorável ao plantio e à adubação de cobertura logo após a chuva.`);
  const secos = c.dias.filter((x) => x.prob < 20);
  if (secos.length >= 3) r.push(`Dias secos para colheita e transporte: ${secos.slice(0, 3).map((x) => fmtD(x.data)).join(", ")}.`);
  if (c.dias.some((x) => x.chuva >= 10)) r.push("Evite aplicar defensivos até 6 h antes de chuvas acima de 10 mm, para não perder o produto.");
  if (c.atual.umidade > 85) r.push("Umidade alta: atenção a doenças fúngicas (ferrugem, mancha-alvo). Monitore os talhões.");
  return r;
}

export const fmtD = (d: string) => new Date(d + "T12:00").toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit" });
