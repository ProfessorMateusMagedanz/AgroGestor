import { useEffect, useState, useCallback } from "react";

export type Item = Record<string, string | number> & { id: string };
export type Collection =
  | "despesas" | "receitas" | "culturas" | "eventos" | "estoque" | "maquinas" | "metas"
  | "animais" | "lotes" | "movimentacoes" | "sanidade" | "pesagens" | "reproducao" | "pastagens"
  | "fornecedores" | "ofertas" | "listaCompras";

export function addTo(c: Collection, it: Record<string, string | number>): Item {
  const item = { ...it, id: crypto.randomUUID() } as Item;
  writeCollection(c, [item, ...readCollection(c)]);
  return item;
}
export function patchIn(c: Collection, id: string, patch: Record<string, string | number>) {
  writeCollection(c, readCollection(c).map((i) => (i.id === id ? ({ ...i, ...patch } as Item) : i)));
}

const KEY = "agrogestor:";
const listeners = new Set<() => void>();

export function readCollection(c: Collection): Item[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(KEY + c) || "[]"); } catch { return []; }
}

export function writeCollection(c: Collection, items: Item[]) {
  localStorage.setItem(KEY + c, JSON.stringify(items));
  listeners.forEach((l) => l());
}

export function useCollection(c: Collection) {
  const [items, setItems] = useState<Item[]>([]);
  useEffect(() => {
    const sync = () => setItems(readCollection(c));
    sync();
    listeners.add(sync);
    return () => { listeners.delete(sync); };
  }, [c]);
  const add = useCallback((it: Omit<Item, "id">) =>
    writeCollection(c, [{ ...it, id: crypto.randomUUID() } as Item, ...readCollection(c)]), [c]);
  const remove = useCallback((id: string) =>
    writeCollection(c, readCollection(c).filter((i) => i.id !== id)), [c]);
  const update = useCallback((id: string, p: Record<string, string | number>) => patchIn(c, id, p), [c]);
  return { items, add, remove, update };
}

export const brl = (n: number) =>
  n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export const sum = (items: Item[], f = "valor") =>
  items.reduce((s, i) => s + (Number(i[f]) || 0), 0);
