import { writeCollection, type Collection } from "@/lib/store";

const d = (offset: number) => new Date(Date.now() + offset * 864e5).toISOString().slice(0, 10);
const m = (monthsAgo: number, day = 10) => { const x = new Date(); x.setMonth(x.getMonth() - monthsAgo, day); return x.toISOString().slice(0, 10); };

const DEMO: Partial<Record<Collection, Record<string, string | number>[]>> = {
  culturas: [
    { talhao: "T-01 Sede", nome: "Soja", area: 320, plantio: m(2, 5), colheita: d(60), insumos: "Semente TMG 2381, MAP 250 kg/ha, KCl 120 kg/ha, glifosato, fungicida", custo: 1376000, produtividade: 64, preco: 125, status: "Em desenvolvimento" },
    { talhao: "T-02 Baixada", nome: "Milho safrinha", area: 180, plantio: m(1, 20), colheita: d(110), insumos: "Híbrido DKB 255, ureia 200 kg/ha, atrazina", custo: 702000, produtividade: 110, preco: 58, status: "Plantada" },
    { talhao: "T-03 Rio", nome: "Algodão", area: 95, plantio: m(3, 1), colheita: d(90), insumos: "Semente FM 985, NPK 04-14-08, inseticida bicudo", custo: 950000, produtividade: 290, preco: 140, status: "Em desenvolvimento" },
    { talhao: "T-04 Divisa", nome: "Feijão", area: 40, plantio: d(15), colheita: d(105), insumos: "Semente BRS Estilo, MAP 200 kg/ha", custo: 128000, produtividade: 45, preco: 260, status: "Planejada" },
  ],
  despesas: [
    { descricao: "Sementes de soja TMG", categoria: "Sementes", valor: 286000, data: m(3) },
    { descricao: "Fertilizante MAP 80 t", categoria: "Fertilizantes", valor: 312000, data: m(3, 18) },
    { descricao: "Diesel S10 12.000 L", categoria: "Combustível", valor: 72000, data: m(2) },
    { descricao: "Fungicida ferrugem", categoria: "Defensivos", valor: 98500, data: m(1) },
    { descricao: "Folha de pagamento", categoria: "Mão de obra", valor: 54000, data: m(1, 28) },
    { descricao: "Revisão colheitadeira", categoria: "Manutenção", valor: 23800, data: m(0, 3) },
    { descricao: "ITR e ICMS", categoria: "Impostos", valor: 18400, data: m(0, 5) },
  ],
  receitas: [
    { descricao: "Venda soja safra anterior 9.000 sc", categoria: "Venda de grãos", valor: 1125000, data: m(4) },
    { descricao: "Venda milho 6.500 sc", categoria: "Venda de grãos", valor: 377000, data: m(2, 15) },
    { descricao: "Venda bezerros 40 cab.", categoria: "Venda de gado", valor: 128000, data: m(1, 12) },
    { descricao: "Arrendamento pasto", categoria: "Arrendamento", valor: 36000, data: m(0, 2) },
  ],
  eventos: [
    { titulo: "Aplicação fungicida T-01", tipo: "Aplicação", data: d(3) },
    { titulo: "Pagar parcela trator", tipo: "Pagamento", data: d(6) },
    { titulo: "Plantio feijão T-04", tipo: "Plantio", data: d(15) },
    { titulo: "Visita do agrônomo", tipo: "Outro", data: d(9) },
  ],
  estoque: [
    { item: "Ureia", quantidade: 18, unidade: "t", minimo: 25, custo: 3200 },
    { item: "Glifosato", quantidade: 1400, unidade: "L", minimo: 800, custo: 28 },
    { item: "Diesel S10", quantidade: 3200, unidade: "L", minimo: 5000, custo: 6 },
    { item: "Semente feijão", quantidade: 60, unidade: "sc", minimo: 50, custo: 410 },
  ],
  maquinas: [
    { nome: "John Deere 8R 340", tipo: "Trator", horas: 4120, manutencao: d(20), status: "Operando" },
    { nome: "Case Axial-Flow 8250", tipo: "Colheitadeira", horas: 2380, manutencao: d(5), status: "Em manutenção" },
    { nome: "Jacto Uniport 3030", tipo: "Pulverizador", horas: 1890, manutencao: d(40), status: "Operando" },
  ],
  metas: [
    { titulo: "Produtividade soja 65 sc/ha", alvo: 65, atual: 64, prazo: d(60) },
    { titulo: "Faturar R$ 3 milhões na safra", alvo: 3000000, atual: 1666000, prazo: d(180) },
    { titulo: "Reduzir custo/ha para R$ 4.000", alvo: 4000, atual: 4300, prazo: d(120) },
  ],
};

export function loadDemo() {
  (Object.keys(DEMO) as Collection[]).forEach((c) =>
    writeCollection(c, (DEMO[c] ?? []).map((r) => ({ ...r, id: crypto.randomUUID() }))));
}
