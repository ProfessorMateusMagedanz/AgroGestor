type P = { kind: string; amount: number | string; status: string };

/** Totais do mês: descontos reduzem o valor líquido. */
export function saldoDoMes(pays: P[]) {
  let pago = 0, pendente = 0, descontos = 0;
  for (const p of pays) {
    const v = Number(p.amount) || 0;
    const s = p.kind === "Desconto" ? -v : v;
    if (p.kind === "Desconto") descontos += v;
    if (p.status === "Pago") pago += s; else pendente += s;
  }
  return { pago, pendente, descontos, liquido: pago + pendente };
}

/** Prazo vencido ou nos próximos 2 dias. */
export function prazoProximo(due: string | null | undefined, hoje: string) {
  if (!due) return false;
  const lim = new Date(hoje + "T12:00:00"); lim.setDate(lim.getDate() + 2);
  return due <= lim.toISOString().slice(0, 10);
}
