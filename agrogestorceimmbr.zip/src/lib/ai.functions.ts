import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

type Out = { ok: true; text: string } | { ok: false; error: string };

async function callAI(body: Record<string, unknown>): Promise<Out> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) return { ok: false, error: "Assistente indisponível no momento." };
  const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
    method: "POST",
    headers: { "Lovable-API-Key": key, "Content-Type": "application/json", "X-Lovable-AIG-SDK": "fetch" },
    body: JSON.stringify({ model: "openai/gpt-6-astra", stream: true, store: false, reasoning: { effort: "low" }, ...body }),
  });
  if (res.status === 429) return { ok: false, error: "Muitas solicitações seguidas. Aguarde um instante e tente de novo." };
  if (res.status === 402) return { ok: false, error: "Os créditos de IA acabaram. Adicione créditos para continuar." };
  if (!res.ok || !res.body) {
    const t = await res.text().catch(() => "");
    console.error("AI error", res.status, t.slice(0, 500));
    return { ok: false, error: "Não consegui analisar agora. Tente novamente." };
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "", out = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const l of lines) {
      if (!l.startsWith("data:")) continue;
      try {
        const ev = JSON.parse(l.slice(5).trim());
        if (ev.type === "response.output_text.delta") out += ev.delta;
      } catch { /* ignore */ }
    }
  }
  return out ? { ok: true, text: out } : { ok: false, error: "A IA não retornou resposta." };
}

const SYS = "Você é o assistente do AgroGestor, especialista em gestão financeira e agronômica de fazendas no Brasil. Responda em português.";

export const askAssistant = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(8000) })).max(30),
      context: z.string().max(20000),
    }).parse(d))
  .handler(async ({ data }) => {
    const r = await callAI({
      instructions: SYS + " Seja prático e objetivo, sem markdown pesado, usando os dados da fazenda quando relevante.\n\nDADOS DA FAZENDA:\n" + data.context,
      input: data.messages.map((m) => ({ role: m.role, content: m.content })),
    });
    return { reply: r.ok ? r.text : r.error };
  });

const imgInput = z.object({ image: z.string().startsWith("data:image/").max(6_000_000), context: z.string().max(8000) });

const str = { type: "string" } as const;
const num = { type: "number" } as const;

const reciboSchema = {
  type: "object", additionalProperties: false,
  required: ["destino", "descricao", "categoria", "valor", "data", "quantidade", "unidade", "resumo"],
  properties: {
    destino: { type: "string", enum: ["despesas", "receitas", "estoque", "maquinas"] },
    descricao: str, categoria: str, valor: num, data: { type: "string", description: "AAAA-MM-DD" },
    quantidade: num, unidade: str, resumo: str,
  },
};

export const readReceipt = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => imgInput.parse(d))
  .handler(async ({ data }) => {
    const r = await callAI({
      instructions: SYS + ` Analise a foto (nota fiscal, recibo, cupom, boleto, comprovante, produto ou máquina) e extraia um lançamento.
destino: "despesas" para compras/pagamentos, "receitas" para vendas/recebimentos, "estoque" quando for produto/insumo armazenado sem valor de compra claro, "maquinas" quando for uma máquina.
Categorias de despesas: Insumos, Sementes, Fertilizantes, Defensivos, Combustível, Mão de obra, Manutenção, Impostos, Outros.
Categorias de receitas: Venda de grãos, Venda de gado, Leite, Hortifruti, Arrendamento, Serviços, Outros.
Unidade: kg, sc, L, t ou un. Se não houver data, use a de hoje (${new Date().toISOString().slice(0, 10)}). Use 0 quando não souber um número. resumo: uma frase explicando o que é a foto.`,
      input: [{ role: "user", content: [
        { type: "input_text", text: "Extraia o lançamento desta foto. Contexto: " + data.context },
        { type: "input_image", image_url: data.image },
      ] }],
      text: { format: { type: "json_schema", name: "lancamento", strict: true, schema: reciboSchema } },
    });
    if (!r.ok) return { error: r.error };
    try { return { result: JSON.parse(r.text) as Record<string, string | number> }; }
    catch { return { error: "Não consegui ler a foto. Tente outra imagem." }; }
  });

const pragaSchema = {
  type: "object", additionalProperties: false,
  required: ["nome", "tipo", "confianca", "descricao", "urgencia", "prevencao", "tratamento", "custo_min", "custo_max", "explicacao_custo"],
  properties: {
    nome: str, tipo: { type: "string", enum: ["Praga", "Doença", "Deficiência nutricional", "Planta daninha", "Saudável", "Não identificado"] },
    confianca: { type: "string", enum: ["Alta", "Média", "Baixa"] }, descricao: str,
    urgencia: { type: "string", enum: ["Baixa", "Média", "Alta"] },
    prevencao: { type: "array", items: str }, tratamento: { type: "array", items: str },
    custo_min: num, custo_max: num, explicacao_custo: str,
  },
};

export const diagnosePest = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => imgInput.parse(d))
  .handler(async ({ data }) => {
    const r = await callAI({
      instructions: SYS + " Você é agrônomo. Identifique a praga, doença ou problema na foto da planta. Dê ações de prevenção e tratamento práticas para o Brasil e estime em reais o custo futuro que o produtor pode ter (tratamento + perdas prováveis se não agir), usando as áreas das culturas cadastradas quando houver. Seja honesto sobre a incerteza e recomende confirmar com um agrônomo.",
      input: [{ role: "user", content: [
        { type: "input_text", text: "Culturas da fazenda: " + data.context },
        { type: "input_image", image_url: data.image },
      ] }],
      text: { format: { type: "json_schema", name: "diagnostico", strict: true, schema: pragaSchema } },
    });
    if (!r.ok) return { error: r.error };
    try { return { result: JSON.parse(r.text) as Diag }; }
    catch { return { error: "Não consegui analisar a foto. Tente outra imagem." }; }
  });

export type Diag = { nome: string; tipo: string; confianca: string; descricao: string; urgencia: string; prevencao: string[]; tratamento: string[]; custo_min: number; custo_max: number; explicacao_custo: string };
