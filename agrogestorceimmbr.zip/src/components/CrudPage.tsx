import { useState, type ReactNode } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useCollection, type Collection, type Item } from "@/lib/store";

export type Field = {
  name: string; label: string; type?: "text" | "number" | "date" | "select"; options?: string[];
};

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string | undefined; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-3xl text-foreground md:text-4xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function CrudPage({
  collection, title, subtitle, fields, renderTitle, renderMeta, renderRight, summary,
}: {
  collection: Collection; title: string; subtitle?: string; fields: Field[];
  renderTitle: (i: Item) => ReactNode; renderMeta?: (i: Item) => ReactNode;
  renderRight?: (i: Item) => ReactNode; summary?: (items: Item[]) => ReactNode;
}) {
  const { items, add, remove } = useCollection(collection);
  const [open, setOpen] = useState(false);

  function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data: Record<string, string | number> = {};
    fields.forEach((f) => {
      const v = String(fd.get(f.name) ?? "");
      data[f.name] = f.type === "number" ? Number(v) || 0 : v;
    });
    add(data);
    setOpen(false);
  }

  return (
    <div>
      <PageHeader
        title={title}
        subtitle={subtitle}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus /> Adicionar</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Novo registro — {title}</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                {fields.map((f) => (
                  <div key={f.name} className="space-y-1">
                    <Label htmlFor={f.name}>{f.label}</Label>
                    {f.type === "select" ? (
                      <select id={f.name} name={f.name} className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm">
                        {f.options?.map((o) => <option key={o}>{o}</option>)}
                      </select>
                    ) : (
                      <Input id={f.name} name={f.name} type={f.type ?? "text"} step="any" required={f.type !== "text" || f.name === fields[0]?.name} />
                    )}
                  </div>
                ))}
                <Button type="submit" className="w-full">Salvar</Button>
              </form>
            </DialogContent>
          </Dialog>
        }
      />
      {summary && <div className="mb-6">{summary(items)}</div>}
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card p-10 text-center text-sm text-muted-foreground">
          Nenhum registro ainda. Toque em “Adicionar” para começar.
        </div>
      ) : (
        <ul className="space-y-2">
          {items.map((i) => (
            <li key={i.id} className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 shadow-soft">
              <div className="min-w-0 flex-1">
                <div className="truncate font-medium text-card-foreground">{renderTitle(i)}</div>
                {renderMeta && <div className="mt-0.5 text-xs text-muted-foreground">{renderMeta(i)}</div>}
              </div>
              {renderRight && <div className="shrink-0 text-right">{renderRight(i)}</div>}
              <Button variant="ghost" size="icon" onClick={() => remove(i.id)} aria-label="Excluir">
                <Trash2 className="text-muted-foreground" />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function StatCard({ label, value, tone = "default" }: { label: string; value: ReactNode; tone?: "default" | "good" | "bad" }) {
  const c = tone === "good" ? "text-success" : tone === "bad" ? "text-destructive" : "text-foreground";
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-1 font-display text-2xl ${c}`}>{value}</div>
    </div>
  );
}
