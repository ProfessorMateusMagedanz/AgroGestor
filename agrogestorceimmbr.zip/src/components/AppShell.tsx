import { useEffect, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import {
  LayoutDashboard, TrendingDown, TrendingUp, Sprout, CalendarDays, Package, Tractor, Target, Bot, FileBarChart, Menu, Wheat, CloudSun, LogIn, LogOut,
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";

const nav = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/despesas", label: "Despesas", icon: TrendingDown },
  { to: "/receitas", label: "Receitas", icon: TrendingUp },
  { to: "/culturas", label: "Talhões e Culturas", icon: Sprout },
  { to: "/clima", label: "Clima", icon: CloudSun },
  { to: "/calendario", label: "Calendário", icon: CalendarDays },
  { to: "/estoque", label: "Estoque", icon: Package },
  { to: "/maquinas", label: "Máquinas", icon: Tractor },
  { to: "/metas", label: "Metas", icon: Target },
  { to: "/assistente", label: "Assistente IA", icon: Bot },
  { to: "/relatorios", label: "Relatórios", icon: FileBarChart },
] as const;

function Brand() {
  return (
    <div className="flex items-center gap-2 px-2">
      <div className="grid size-9 place-items-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground"><Wheat className="size-5" /></div>
      <span className="font-display text-xl">AgroGestor</span>
    </div>
  );
}

function Account() {
  const [email, setEmail] = useState<string | null>(null);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setEmail(data.session?.user.email ?? null));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setEmail(s?.user.email ?? null));
    return () => data.subscription.unsubscribe();
  }, []);
  if (!email)
    return <Link to="/auth" className="mt-6 flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-sidebar-accent"><LogIn className="size-4" /> Entrar</Link>;
  return (
    <div className="mt-6 rounded-lg bg-sidebar-accent/50 px-3 py-2 text-xs">
      <div className="truncate">{email}</div>
      <button onClick={() => supabase.auth.signOut()} className="mt-1 flex items-center gap-1 opacity-80 hover:opacity-100"><LogOut className="size-3" /> Sair</button>
    </div>
  );
}

function NavList({ onNav }: { onNav?: () => void }) {
  return (
    <nav className="mt-6 space-y-1">
      {nav.map(({ to, label, icon: Icon }) => (
        <Link key={to} to={to} onClick={onNav} activeOptions={{ exact: true }}
          className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
          activeProps={{ className: "bg-sidebar-accent text-sidebar-foreground font-medium" }}>
          <Icon className="size-4" /> {label}
        </Link>
      ))}
    </nav>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen bg-background">
      <aside className="fixed inset-y-0 left-0 hidden w-60 print:hidden bg-sidebar p-4 text-sidebar-foreground md:block">
        <Brand /><NavList /><Account />
      </aside>
      <header className="sticky top-0 z-30 print:hidden flex items-center justify-between bg-sidebar px-4 py-3 text-sidebar-foreground md:hidden">
        <Brand />
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger aria-label="Menu" className="rounded-md p-2 hover:bg-sidebar-accent"><Menu /></SheetTrigger>
          <SheetContent side="left" className="w-64 border-none bg-sidebar p-4 text-sidebar-foreground">
            <SheetTitle className="sr-only">Menu</SheetTitle>
            <Brand /><NavList onNav={() => setOpen(false)} /><Account />
          </SheetContent>
        </Sheet>
      </header>
      <main className="px-4 py-6 md:ml-60 print:ml-0 md:px-10 md:py-10">
        <div className="mx-auto max-w-5xl">{children}</div>
      </main>
    </div>
  );
}
