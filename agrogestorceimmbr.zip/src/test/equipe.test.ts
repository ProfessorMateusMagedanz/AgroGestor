import { describe, expect, it } from "vitest";
import { prazoProximo, saldoDoMes } from "@/lib/equipe";

describe("equipe", () => {
  it("desconto reduz o líquido", () => {
    const r = saldoDoMes([{ kind: "Salário", amount: 2000, status: "Pendente" }, { kind: "Desconto", amount: 300, status: "Pendente" }, { kind: "Adiantamento", amount: 500, status: "Pago" }]);
    expect(r.liquido).toBe(2200);
    expect(r.pago).toBe(500);
  });
  it("aviso de prazo até 2 dias antes", () => {
    expect(prazoProximo("2026-11-07", "2026-11-05")).toBe(true);
    expect(prazoProximo("2026-11-08", "2026-11-05")).toBe(false);
  });
});
