# AgroGestor — auditoria e plano de evolução

## Diagnóstico executivo

**O AgroGestor já é um protótipo funcional, mas ainda não é uma plataforma comercial pronta para receber dados de clientes e cobrar assinaturas.** Há cadastros reais, cálculos, calendário, previsão externa e caminhos de IA. A principal lacuna é a ausência de armazenamento central, contas de usuários e isolamento por propriedade.

Nenhum código, integração ou dado existente foi alterado nesta auditoria. Os testes de cadastro usaram um navegador temporário isolado, sem acessar os registros do produtor. Foram criados apenas documentos de requisitos, auditoria e planejamento.

### Evidências verificadas

- As 11 telas abriram com resposta 200 no ambiente de desenvolvimento, sem erros de execução capturados.
- Cadastrei uma despesa de **R$ 123,45**; ela permaneceu após atualizar a página, apareceu no Dashboard e no resultado mensal dos Relatórios.
- O botão Excel baixou um arquivo **CSV**, contendo essa despesa. Não é uma pasta de trabalho Excel `.xlsx`.
- A tela Clima exibiu previsão de sete dias para **Sorriso, MT**. Essa cidade é real, mas é o padrão do sistema: não comprova que seja a localização da propriedade.
- As imagens conferidas mostram a página inicial no computador e celular; não houve rolagem horizontal na página inicial de 390 px. Isso não equivale a validar todas as telas em celulares.
- O teste automatizado existente passou: **1 teste**, limitado ao registro da rota inicial.

**Não verificado nesta rodada:** respostas ao vivo de IA, análise de fotos, geolocalização, busca de outra cidade, impressão/PDF, todos os cadastros e exclusões, configuração de serviços em produção, backups do provedor, autenticação ou pagamentos. Não há testes suficientes para afirmar que todos os módulos funcionam integralmente.

## 1. Arquitetura e dados

### Estrutura atual

Aplicação web em React 19 e TanStack Start/Router, com Tailwind CSS, componentes Radix, gráficos Recharts, validação Zod e testes Vitest. O manifesto atual declara Vite 8 e configuração centralizada pelo preset Lovable; não é necessário trocar essas tecnologias para evoluir.

As páginas ficam em `src/routes`. Os cadastros simples compartilham `CrudPage`. O módulo `src/lib/store.ts` centraliza sete coleções: despesas, receitas, culturas, eventos, estoque, máquinas e metas. Localização e clima possuem chaves locais próprias. As funções de IA usam o Lovable AI Gateway no servidor.

**Não existe banco de dados conectado, tabelas relacionais ou políticas de acesso.** As coleções são documentos no armazenamento do navegador. Não há vínculo obrigatório entre uma despesa, um talhão, uma safra, uma máquina ou um produto. Sem essa relação, não se pode atribuir custos com segurança a cada atividade.

### Consequências

- Troca de aparelho leva os registros junto; limpeza do navegador não pode apagá-los.
- Pessoas que compartilham o mesmo navegador/origem podem acessar as mesmas coleções.
- Devem existir contas, equipes, autorização por propriedade ou histórico de quem alterou dados.
- A demonstração escreve nas mesmas coleções que os registros reais: pode substituí-los após confirmação. Para uso comercial, deve existir um ambiente de demonstração separado.
- A estrutura centralizada de armazenamento favorece uma evolução preservando as telas; não exige reconstrução do projeto.

## 2. O que funciona, funciona parcialmente e falta


| Área                      | Situação atual                                                                       | O que falta para uso profissional                                                                             |
| ------------------------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------- |
| Despesas e receitas       | Cadastro, listagem e totais; fluxo de despesa verificado                             | Edição, validação, categorias próprias, vencimentos, pagamento/recebimento, safra, talhão e centros de custo  |
| Dashboard                 | Saldo, gráficos mensais, área e próximas atividades conectados às coleções           | Filtros, comparação, contas pendentes, alertas integrados e identificação do período                          |
| Talhões e culturas        | Identificação, hectares, plantio, colheita prevista, insumos, custos e produtividade | Safra, localização, histórico, aplicações e relações com lançamentos; mapa apenas com dados geográficos       |
| Calendário                | Lembretes por data e próximos eventos no Dashboard                                   | Edição, prioridades, conclusão, notificações e integração automática com vencimentos/manutenção               |
| Estoque                   | Quantidade, unidade, custo e indicador abaixo do mínimo                              | Entradas/saídas, histórico, lotes, validade, fornecedores e baixa por uso                                     |
| Máquinas                  | Cadastro, horas, próxima manutenção e status                                         | Histórico, peças, combustível, despesas vinculadas, documentos e calendário preventivo                        |
| Metas                     | Barra de progresso calculada com valor atual informado manualmente                   | Atualização pelos registros e distinção entre meta de aumento e redução de custos                             |
| AgroScan                  | Código prevê confirmação da foto, revisão editável e confirmação do destino          | Validar resultado da IA, impedir duplicidade, campos incompletos e vínculos; não testado ao vivo              |
| Assistente                | Recebe contexto das coleções; caminhos de diagnóstico e lembrete existentes          | Histórico durável, período explícito, origem dos números, limites de uso e proteção por usuário               |
| Clima                     | Previsão externa de sete dias, chuva, temperatura, umidade, vento e alertas          | Fonte/horário visíveis, atualização segura, histórico e vínculo à propriedade; recomendações contextualizadas |
| Relatórios                | Totais, gráficos, resultado mensal e CSV verificados                                 | Filtros, relatórios por safra/talhão, `.xlsx` real e PDF padronizado; PDF atual é impressão do navegador      |
| Comercialização           | Não implementada                                                                     | Página comercial, planos controlados, teste gratuito, assinatura e cobrança real                              |
| Contas e segurança        | Sem contas próprias e sem isolamento de clientes                                     | Login, permissões, documentos privados, auditoria, recuperação e backups                                      |
| Suporte/administração/PWA | Não implementados como produto completo                                              | Atendimento real, chamados, gestão comercial, instalação e estratégia de sincronização                        |


As principais funcionalidades ausentes não estão “quebradas”: ainda precisam ser desenvolvidas. Ausência de edição e relações limita módulos existentes; não deve ser encoberta por novas telas.

## 3. Riscos que merecem prioridade

1. **Perda de registros e ausência de isolamento:** armazenamento apenas local, sem cópia central ou controle por propriedade (`store.ts`).
2. **Contas que parecem comparáveis, mas usam bases diferentes:** Dashboard divide custos informados nas culturas pela área; Relatórios divide despesas pela área. Definir um único significado e separar custo planejado de gasto registrado (`index.tsx`, `relatorios.tsx`, `culturas.tsx`).
3. **Produtividade misturada:** média ponderada entre culturas diferentes não representa uma medida agronômica comparável. Separar por cultura, unidade e safra.
4. **Validação insuficiente:** números inválidos podem virar zero; valores negativos, datas incoerentes e formatos de armazenamento não são tratados de forma consistente. A extração da IA não é validada integralmente antes de gravação.
5. **Demonstração sobre dados reais e exclusão sem confirmação:** riscos evitáveis de apagar registros (`demo.ts`, `CrudPage.tsx`).
6. **IA sem controles próprios suficientes:** não há autenticação/cotas por cliente no código examinado. Dados e fotos são enviados ao serviço externo; retenção e configuração efetivas não foram verificadas. A chave é lida no servidor, um controle positivo.
7. **Recomendações agronômicas:** alertas climáticos usam regras fixas; diagnóstico e custo futuro de praga dependem do modelo. Não são laudos nem orçamento validado. Evitar orientações conclusivas sem cultura, fase, contexto e fontes.
8. **CSV:** campos de registros posteriores podem ser omitidos quando só o primeiro define as colunas; valores iniciados como fórmulas precisam de proteção antes de abrir em planilhas (`export.ts`).
9. **Testes insuficientes:** um teste de rota não garante cálculos, permissões, persistência ou integrações.

Os títulos e descrições existem nas 11 páginas. Oito páginas não declaram todos os metadados sociais na própria rota. É uma melhoria secundária, não motivo para alterar o aplicativo durante a auditoria.

## 4. Desenvolvimento por etapas

### Etapa 1 — Base confiável, preservação e segurança

Primeira entrega proposta, antes de ampliar funcionalidades:

- Confirmar quais dados de perfil serão armazenados antes de escrever autenticação.
- Ativar Lovable Cloud para armazenamento durável, contas e documentos privados, sem apagar as coleções atuais.
- Modelar usuários, propriedades e participação de equipes; impedir acesso cruzado entre clientes.
- Criar importação **voluntária**, com conferência dos registros locais, proteção contra duplicidade e leitura de volta pela tela antes de considerar a migração concluída.
- Separar demonstração de registros reais, mantendo os recursos existentes.
- Validar entradas e cálculos essenciais; tratar falhas de gravação e oferecer exclusão com confirmação e edição.
- Registrar alterações e definir recuperação/backup, verificando os recursos realmente disponíveis no serviço.

**Critério de aceite:** dois usuários em propriedades diferentes não acessam dados um do outro; cadastro persiste e aparece em outro aparelho autorizado; importação conserva os registros; valores financeiros são cobertos por testes concretos.

### Etapa 2 — Produtor, financeiro e integração

Organizar a página inicial sem excesso de informações; adicionar filtros de período/safra, contas a pagar/receber e “Atenção à sua propriedade”. Unificar cálculos e vincular despesas, culturas, talhões, estoque, máquinas e calendário. Acrescentar movimentações, histórico e metas calculadas a partir dos dados. Criar exportações filtradas em Excel e PDF profissional.

### Etapa 3 — IA e AgroScan confiáveis

Conservar as confirmações obrigatórias. Validar campos extraídos, destacar ilegibilidade, detectar duplicidade e permitir vínculo confirmado entre nota e estoque/financeiro. Respostas com período, registros de origem, dados faltantes e estimativas separadas. Histórico protegido, limites de uso e recomendações agronômicas prudentes.

### Etapa 4 — Comercialização e cobrança

Página comercial pública, sem substituir a experiência de gestão. Planos editáveis: Essencial R$ 39,90, Profissional R$ 79,90 e Premium R$ 149,90 por mês; teste de 14 dias. Definir limites efetivos e preços anuais sem inventá-los. Integrar provedor com confirmação segura, cancelamento e histórico. Nunca simular pagamento aprovado ou guardar dados completos de cartão.

### Etapa 5 — Configuração inicial, suporte e administração

Cadastro orientado da propriedade com etapas puláveis; suporte e chamados, permissões administrativas verificadas e indicadores comerciais calculados de dados reais. Usar WhatsApp apenas quando houver contato fornecido. Política de privacidade e termos exigem informações reais do responsável e revisão adequada; uma tela não comprova conformidade LGPD.

### Etapa 6 — Celular e expansão

PWA instalável, aviso de conexão e sincronização testada. Offline apenas com estratégia segura contra conflito e perda. Estudar integrações com balanças, equipamentos, cooperativas, cotações e agricultura de precisão: identificar fornecedores, APIs, custos e permissões antes de implementar.

## 5. Dependências e limites de aprovação

**A aprovação deste plano autoriza começar pela Etapa 1, não executar todas as etapas de uma vez.** Cada entrega será verificada antes da próxima.

- Lovable Cloud e eventuais serviços exigem ativação e podem gerar custos; não foram ativados nesta auditoria.
- Antes de autenticação será confirmada a necessidade de dados de perfil.
- Pagamentos exigem conta de provedor, credenciais e decisões sobre limites dos planos e preços anuais.
- WhatsApp, identidade jurídica, contatos e documentos legais dependem de informações verdadeiras do responsável.
- Não há garantia de disponibilidade comercial dos serviços de clima sem verificar licença, limites e eventual plano pago.
- Integrações futuras terão estudo próprio; não serão apresentadas como prontas.

**Maior impacto para o produtor:** não perder registros, corrigir lançamentos com facilidade, saber o que vence e comparar custos reais por talhão sem duplicidade. Para a banca, a demonstração mais convincente é esse fluxo completo funcionando, não apenas uma lista maior de telas.