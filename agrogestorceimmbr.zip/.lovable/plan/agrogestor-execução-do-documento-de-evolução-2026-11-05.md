# AgroGestor — execução do documento de evolução

O documento pede seis grandes etapas. Elas serão entregues em sequência, cada uma testada antes da próxima, sem apagar registros nem remover funções.

## Entrega 1 (agora) — fechar a base
- Salvar os registros na conta do usuário, e não só neste aparelho.
- Botão "Trazer meus registros deste aparelho": mostra quantos registros de cada seção serão enviados, pede confirmação, evita duplicados e confere na tela depois.
- Editar lançamentos e confirmar antes de excluir, em todas as seções.
- Demonstração separada dos dados reais (não sobrescreve mais nada).
- Validação de valores (sem negativos, datas coerentes).

## Entrega 2 — produtor e financeiro
- Página inicial mais limpa com "Atenção à sua propriedade" (vencimentos, estoque baixo, manutenção, clima).
- Filtro por período e safra; contas a pagar e a receber.
- Despesas ligadas ao talhão, à máquina e ao estoque; custo por hectare com um único cálculo.
- Metas calculadas a partir dos lançamentos.
- Excel de verdade e PDF com aparência profissional.

## Entrega 3 — IA e AgroScan
- Conferência dos campos lidos da foto, aviso de duplicidade, ligação com estoque e financeiro (sempre com confirmação da foto e do destino).
- Respostas mostrando de quais registros vieram os números.

## Entrega 4 — página de venda e planos
- Página pública de apresentação e planos Essencial R$ 39,90, Profissional R$ 79,90, Premium R$ 149,90, teste de 14 dias.
- Cobrança real só depois de escolher o serviço de pagamento; nada de pagamento simulado.

## Entrega 5 — configuração inicial e suporte
- Cadastro guiado da propriedade, área de suporte e painel administrativo.

## Entrega 6 — celular
- Instalação no celular e aviso de falta de conexão.

## O que depende de você
- Serviço de pagamento (Stripe ou Paddle) para cobrança real.
- Contato de WhatsApp/e-mail de suporte e dados do responsável para termos e privacidade.
- Limites de cada plano e preços anuais.

## Detalhes técnicos
- Trocar `src/lib/store.ts` por adaptador com o banco (tabela `farm_records` já criada), mantendo a mesma interface `useCollection`, mais `update`.
- Importação pela função já criada, com deduplicação por ID.
- Testes de cálculo (custo/ha, saldo, metas) em Vitest.
