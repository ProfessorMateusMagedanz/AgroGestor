<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Norte

Produtores sabem para onde vai seu dinheiro e mantêm a fazenda lucrativa.

## Métrica

Despesas e receitas lançadas por semana
